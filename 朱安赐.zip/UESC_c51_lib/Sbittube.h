#ifndef __Key_H__
#define __Key_H__
#include <regx51.h>
sbit com1=P2^4; 
sbit com2=P2^5; 
sbit com3=P2^6; 
sbit com4=P2^7; 
#define uchar unsigned char
#define uint unsigned int
int display(int num);
void delayms(uint tms);
#endif					 