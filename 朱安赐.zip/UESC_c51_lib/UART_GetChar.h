#include <REGX51.H>
#define uchar unsigned char
#define uint unsigned int
void UESC_UART_GetChar(void);
