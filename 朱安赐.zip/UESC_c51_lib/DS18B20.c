#include <REGX51.H>
#include "DS18B20.h"
#include "Sbittube.h"
#include <intrins.h>
uint temp;
float f_temp;
void Delay2us()		//@12.000MHz
{
	unsigned char i;

	i = 3;
	while (--i);
}


void Delay45us()		//@12.000MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 1;
	j = 130;
	do
	{
		while (--j);
	} while (--i);
}


void Delay15us()		//@12.000MHz
{
	unsigned char i;

	i = 42;
	while (--i);
}


void Delay1ms()		//@12.000MHz
{
	unsigned char i,j;

	_nop_();
	_nop_();
	i = 12;
	j = 168;
	do
	{
		while (--j);
	} while (--i);
}


void Delay70us()		//@12.000MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 1;												 +

	j=205;
	do
	{
		while (--j);
	} while (--i);
}


void Delay750us()		//@12.000MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 9;
	j = 189;
	do
	{
		while (--j);
	} while (--i);
}

void Delay30us()		//@12.000MHz
{
	unsigned char i;

	i = 87;
	while (--i);
}
	   
void dsreset(void)//DS18B20��λ����ʼ������
{

 ds=0;
 Delay750us();	 //��ʱ480-960us
 ds=1;
 Delay30us();	//��ʱ15-60us
}

bit tempreadbit(void) //��ȡһλ���ݺ���
{
 
 bit dat;
 ds=1;
 Delay2us(); //�ӳ�2us
 ds=0;
 Delay2us();Delay2us();Delay2us(); //�ӳ�6us
 ds=1;
 Delay2us();Delay2us();	//�ӳ�4us
 dat=ds;
 Delay30us();  //��ʱ30us
 return(dat);
}

uchar tempread(void) //��ȡһ���ֽ�
{
 uchar i,j,dat;
 dat=0;
 for(i=1;i<=8;i++)//��8��
 {
  j=tempreadbit();
  dat=(j<<7)|(dat>>1);//�������������λ��ǰ��
 }
 return(dat);
}

void tempwritebyte(uchar dat) //��DS18B20дһ���ֽ����ݺ���
{
 
  uchar j;
  bit testb;
  for(j=1;j<=8;j++)
  {
  	 testb=dat&0x01;
	 dat=dat>>1;
	 if(testb) //д1
	 {
	 ds=0;
	 Delay15us();//�ӳ�15us
	 ds=1;
	 Delay45us(); //�ӳ�45us
	 }
	 else  //д0
	 {
	  ds=0;
	  Delay45us();//�ӳ�45us
	  ds=1;
      Delay15us();//�ӳ�15us
	} 
  }
  
 }
void  tempchange(void) //DS18B20 ��ʼ��ȡ�¶Ȳ�ת��
{
  
  dsreset();
  Delay1ms();
  tempwritebyte(0xcc);
  tempwritebyte(0x44);

}
uint get_temp() //��ȡ�Ĵ����д洢���¶�����
{
  uchar a,b;
  uint temp;
  float T;
  dsreset();
  Delay1ms();
  tempwritebyte(0xcc);
  tempwritebyte(0xbe); 
  a=tempread();            
  b=tempread();
  temp=b;
  temp<<=8;
  temp=temp|a;
  T=temp*0.0625;
  temp=T*100+0.5;
  T=T+0.05;
  return (temp);
}







