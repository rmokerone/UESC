#include <REGX51.H>
#include "PCA_pwm.h"

void init()
{
 CCON=0;
 CL=0;
 CH=0;
 CMOD=0x08;

}

char PCA_pwm(mode,witch)
{

 init();
 switch(mode)
 {
   case 0:
    CCAPM0 = 0x42;
	CCAP0L = CCAP0H = witch; 
     break;
   case 1:
    CCAPM1 = 0x42;
	CCAP1L = CCAP1H = witch; 
 	break;
 }
 CR=1;

}

