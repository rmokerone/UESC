#include <regx51.h>
#include "../UART_Init.h"

void main()
{
 UESC_UART_Init(4800);
}