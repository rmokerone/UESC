#include<regx51.h>
#include "../Sbittube.h"
#include "../Key.h"

void main()
{
 while(1)
 {
  display(4440); 
 }
} 