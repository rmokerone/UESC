#include <regx51.h>
#include "../AD_Init.h"
#include "../Sbittube.h"

void main()
{
 UESC_AD_Init(0);
 while(1)
 {		int k,a;
  a = (int)(num1*1000);
  for(k=0;k<1000;k++)
  {
  	display(a);
  }
 }
}