#include <REGX51.H>
#include "../DS18B20.h"
#include "../Sbittube.h"

void main()
{
  int x;
  while(1)
  {
   tempchange();
   for(x=20;x>0;x--)
    display(get_temp());
  }
}