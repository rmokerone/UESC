#include <REGX51.H>
#include "AD_Init.h"
#include "Sbittube.h"
#include "intrins.h"
float num1 ;

char gall;

void ADC() interrupt 5 using 1
{
  ADC_CONTR&=!ADC_FLAG;
  num1=(ADC_RES<<2|ADC_RESL)*5/1024;
  ADC_CONTR=ADC_POWER|ADC_SPEEDLL|ADC_START;
}	

void UESC_AD_Init(char gall)
{
  
  P1ASF=0xff;
  ADC_RES=0;
  ADC_RESL=0;
  ADC_CONTR=ADC_POWER|ADC_SPEEDLL|ADC_START|gall;
  _nop_();   _nop_();
   _nop_();   _nop_(); 
    _nop_();   _nop_(); 
  IE=0xa0;
 }



