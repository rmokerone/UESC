#include <regx51.h>
#include "../UART_PutChar.h"
void main()
{
 UESC_UART_PutChar('a');
}