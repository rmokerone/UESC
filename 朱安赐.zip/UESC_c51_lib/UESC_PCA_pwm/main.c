#include <REGX51.H>
#include "../PCA_pwm.h"
char i,witch=0;

void main()
{
	init();
 while(1)
 {	
	if(witch==0)
	{
	while(witch<255)
    {
	 witch++;
	 PCA_pwm(1,witch);
	 delay(50);
    }
   	}
   
   if(witch==255)
   { 
	while(witch>0)
	{
	witch--;
   	PCA_pwm(1,witch);
	delay(50);
   	}
   }
  }
}
void delay(int t)
{
 int x,y;
 for(x=t;x>0;x--)
  for(y=110;y>0;y--);
}