#include<regx51.h>
#include "Key.h"
char UESC_TestKey(unsigned char IO)
{
	switch(IO/10)
	{
 		case 0:
    if(!(P0&(1<<(IO%10))))
    {
   	 delayms(10);
  
    return 1;
	} 
	  
    break;
    case 1:
    if(!(P1&(1<<(IO%10))) )
   {
   	delayms(10);
     return 1;
   }
   break;
   case 2:
    if(!(P2&(1<<(IO%10))))
   {
   	delayms(10);
    return 1;
    
   }
   break;
  case 3:
    if(!(P3&(1<<(IO%10))))
   {
   	delayms(10);
     return 1;
    
   }
  break;
 }
 return 0;
}

void delayms(uint tms)
{  
  int x,y;
  for(x=tms;x>0;x--)
   for(y=110;y>0;y--);
}



