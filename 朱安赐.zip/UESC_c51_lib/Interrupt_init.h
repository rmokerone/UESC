#include <REGX51.H>
extern int n;
//char UESC_TestKey(unsigned char IO);
void UESC_Interrupt_init();
void a();


