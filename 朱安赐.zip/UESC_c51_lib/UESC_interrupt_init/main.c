#include <REGX51.H>
#include "../Interrupt_init.h"
#include "../Sbittube.h"
#include <intrins.h>


void main()
{
 P1=0xff;
 UESC_Interrupt_init();
 //display();
 
 while(1)
 {
  
  P0_1=1;
  _nop_;
  P0_1=0;
  _nop_;

 }



}