#include <REGX51.H>
#include "Interrupt_init.h"
#include "Sbittube.h"

int n=0;
int x,y;

void UESC_Interrupt_init()
{
 EA=1;
 EX0=1;
 IT0=1;
}


void a() interrupt 0
{
 EA=0;
 P1=~P1;
 //n++;
 for(x=0;x<=1000;x++)
  for(y=0;y<=110;y++);
 //while(!INT0);
 EA=1;
}


