#include <regx51.h>
#define uchar unsigned char
#define uint unsigned int
void UESC_UART_Init(uint band);