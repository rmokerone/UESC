#include <REGX51.H>
#define uchar unsigned char
#define uint unsigned int
extern float num1;
#define ADC_POWER 0x80
#define ADC_FLAG 0x10
#define ADC_START 0x08
#define ADC_SPEEDLL 0x00
#define ADC_SPEEDL 0x20
#define ADC_SPEEDH 0x40
#define ADC_SPEEDHH 0x60
sfr ADC_CONTR = 0xBC;
sfr ADC_RES = 0xBD;
sfr ADC_RESL = 0xBE;
sfr P1ASF = 0x9D;
void UESC_AD_Init(char gall);

void delay(uint t);