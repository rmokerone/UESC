#include <regx51.h>
#include "../Interrupt_GetDate.h"
#include "../Sbittube.h"
void main()
{
  UESC_Interrupt_GetDate(50);
 while(1)
 {
 
 display(n);
}
}

