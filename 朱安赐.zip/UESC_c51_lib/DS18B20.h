#include <REGX51.H>
#define uint unsigned int
#define uchar unsigned char

sbit ds=P2^2;

bit tempreadbit(void);	 
void dsreset(void);
uchar tempread(void);
void tempwritebyte(uchar dat);
void tempchange(void);
uint get_temp();
void delay();






