#include<reg51.h>
#include "../LED.h"


    void main()
{
 	UESC_openLED(P12);
}