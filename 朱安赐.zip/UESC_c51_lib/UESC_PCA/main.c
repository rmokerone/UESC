#include <regx51.h>
#include "../PCA_capture.h"

void main()
{
while(1)
 {
 init();
 UESC_PCA_capture(0,0);
 }
}
