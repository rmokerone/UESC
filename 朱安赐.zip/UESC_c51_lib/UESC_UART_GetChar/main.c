#include <regx51.h>
#include "../UART_GetChar.h"
void main()
{
 UESC_UART_GetChar();
}