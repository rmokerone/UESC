#include<regx51.h>
#include "Sbittube.h"
#include "Key.h"
uchar i;
uchar code table[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
int num;
uint qian,bai,shi,ge;
void delayms(uint tms)
{
 uint x,y;
 for(x=tms;x>0;x--)
  for(y=10;y>0;y--);
}			               



int display(int num)
{
  if (num>9999||num<0)
  return 0;	
  qian=num/1000;
  bai=num%1000/100;
  shi=num%100/10;
  ge=num%10;
 for(i=0;i<4;i++)
 {
  switch (i)
  {
   case 0:com2=0;com1=1;com3=1;com4=1;	
          P0=table[ge];
          
          break;
   case 1:com2=1;com1=0;com3=1;com4=1;
   		  P0=table[shi];
           
           break;
   case 2:com2=1;com1=1;com3=1;com4=0;	
   		   P0=table[bai];
           P0_2=0;
           break;
   case 3:com2=1;com1=1;com3=0;com4=1;	
   		   P0=table[qian];
    
           break;
  }

  delayms(5);
  P0=0xff;
 }
 return 1;

}