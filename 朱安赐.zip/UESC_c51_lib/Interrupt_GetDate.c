#include <regx51.h>
#include "Interrupt_GetDate.h"
#include "Sbittube.h"
int time;
n=0;

void UESC_Interrupt_GetDate(char t)
{
 time=t*1000;
 TMOD=0x01;
 TH0=(65536-time)/256;
 TL0=(65536-time)%256;
 EA=1;
 ET0=1;
 TR0=1;
}


void a() interrupt 1
{
 TH0=(65536-time)/256;
 TL0=(65536-time)%256;
 n++;
 if(n==9999)
 n=0;
}