#include <regx51.h>

extern int n;
void UESC_Interrupt_GetDate(char t);

