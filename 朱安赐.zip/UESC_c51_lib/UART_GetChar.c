#include <regx51.h>
#include "UART_GetChar.h"
uchar a,flag;
void init()
{
 TMOD=0x20;
 TH0=0xfd;
 TL0=TH0;
 TR1=1;
 REN=1;
 SM0=0;
 SM1=1;
 EA=1;
 ES=1;

}

void UESC_UART_GetChar(void)
{
	init();
	SBUF=a;
	while(!TI);
	TI=0;
	ES=1;
	flag=0;	
}

void ser() interrupt 4
{
 RI=0;
 a=SBUF;
 flag=1;
}