#include <REGX51.H>
#include "PCA_capture.h"

void UESC_PCA_capture(char module,mode)
{
  switch(module)
   {
   	case 0:
    switch(mode)
   	{
	case 0: 
	  CCAPM0 = 0x21; break;
    case 1:
    CCAPM0 = 0x11;	break;
  	}	
		
	
   case 1:
    
	switch(mode)
   	{
	case 0:  
	  CCAPM1 = 0x21; break;
    case 1:
    CCAPM1 = 0x11;	break;
  	} 
	 
  }
 CR = 1; //PCA��ʱ����ʼ����
 EA = 1;
}	  


void init()
{
                //(P1.2/ECI, P1.1/CCP0, P1.0/CCP1, P3.7/CCP2)
    
 CCON=0;
 CL=0;
 CH=0;
 CMOD=0x00;
 
}

void PCA() interrupt 7
{
 EA=0;
 CCF0 = 0; 
 P1_1=!P1_1;
 EA=1;
}
