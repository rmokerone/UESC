#include"reg51.h"

unsigned int UESC_AD_Init();
unsigned int UESC_AD_GetData(gall);
unsigned int UESC_AD_GetVol(vol,gall);



    

#define ADC_POWER 0x80
#define ADC_FLAG 0x10
#define ADC_START 0x08
#define ADC_SPEEDLL 0x00  
#define ADC_SPEEDL 0x20
#define ADC_SPEEDH 0x40
#define ADC_SPEEDHH 0x60 


sfr ADC_CONTER =0xbc;
sfr ADC_RES =0xbd;
sfr ADC_LOW2 =0xbe;
sfr P1ASF =0x9d;


typedef unsigned char byte;
typedef unsigned int word; 
