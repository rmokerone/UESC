#include<reg51.h>

#ifndef _tube_h_
#define _tube_h_
#endif

#define P00 0
#define P01 1
#define P03 3
#define P04 4
#define P05 5
#define P02 2
#define P06 6
#define P07 7

sbit wela1=P2^6;
sbit wela2=P2^7;
sbit wela3=P2^4;
sbit wela4=P2^5;

char UESC_TubeDisplay(unsigned int number);
char UESC_TubeDisplay_Bit(char number, char tubebit);

void delayms(unsigned int xms);


