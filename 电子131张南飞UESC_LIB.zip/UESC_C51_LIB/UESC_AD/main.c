#include"reg51.h"
 
#include"../AD.h"
#include"../tube.h"

unsigned int gall;

unsigned int n;

void main()
{
	UESC_AD_Init();
 
	while(1)
	{
	 
		n++;
		while(n==20)
			{
				n=0;
			}
	   	UESC_TubeDisplay(UESC_AD_GetData(0));
	}	
}
