#ifndef	_TIME_H__
#define _TIME_H__

#include"reg51.h"


#define FOSC  12000000L



sbit led1=P1^1;



void Time_Init();

#endif
