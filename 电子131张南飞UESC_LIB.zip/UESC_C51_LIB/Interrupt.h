#include"reg51.h"

void UESC_Interrupt_Init();

void delayms(unsigned int xms);

								  
sbit  led1=P1^0;
sbit  led7=P1^7;