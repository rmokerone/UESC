#include<reg51.h>
#include"../tube.h"
void main()
{
	while(1)
	{
		 //UESC_TubeDisplay_Bit(8,3);
	 	UESC_TubeDisplay(5678);
	}

}