#include"reg51.h"


 

 
char UESC_UART_Init(void);
char UESC_UART_GetChar(void);
char UESC_UART_PutChar(unsigned char dat);