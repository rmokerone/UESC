#include"reg51.h"
#include"../Time.h"

void main()
{
	Time_Init();
	while(1);
}