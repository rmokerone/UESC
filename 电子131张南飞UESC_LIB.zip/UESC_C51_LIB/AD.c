#include"reg51.h"
#include"AD.h"


//unsigned int gall;

unsigned int result;
void UESC_AD_Init(gall) 
{
	    P1ASF = 0xff;                   //����P1��ΪAD��
        ADC_RES = 0;                    //�������Ĵ���
        ADC_CONTR = ADC_POWER | ADC_SPEEDLL;
        ADdelayms(2);                       //ADC�ϵ粢��ʱ
}


unsigned int UESC_AD_GetData(gall)
{
  
	unsigned int hh,ll;
	UESC_AD_Init(0) ;
	hh=ADC_RES;
	ll=ADC_LOW2;
	result=(hh<<2)+ll;
	return result;
}
	 

float UESC_AD_GetVol(vol,gall)
{
	float t; 
	//vol=result/1024*VCC;
	t=result*vol/1024;
	ADC_CONTR&=~ADC_FLAG;
	return t;
		 
	 
}

void ADdelayms(unsigned int xms)
{
	unsigned int i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);
}
