#include<reg51.h>
#include "../key.h"

void main()
{
	while(1)
	{
   	if(UESC_TestKey(P31))
		 P1 = 0xfe;
   }
}