#include"reg51.h"
#include "../UART.h"
 
extern unsigned char recv;

unsigned int i;
 
void main()
{
	UESC_UART_Init();
	while(1)
	{
		
		UESC_UART_PutChar(recv);
 		P1=recv;
	}
}
