#include"reg51.h"
#include"../DS18B20.h"
#include"../tube.h"
//sbit d=P1^1;

void main()
{	

	//UESC_DS18B20_init();
	while(1)
	{
	  
	 //	tempwritebyte(12);
	 //	tempreadbit();
	//	tempread();
	 
 	tempchange(); 

	//	tempreadbit(0xbe);
		
	//	d=0; 
		//UESC_UART_PutChar(0X33);
			
	UESC_TubeDisplay(get_temp());
	}


}