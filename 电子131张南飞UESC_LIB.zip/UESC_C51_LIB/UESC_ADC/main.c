#include"reg51.h"
#include"../ADC.h"
#include"../UART.h"


void main()
{
	UESC_AD_Init();
	UESC_UART_Init();
	while(1)
	{

		UESC_UART_PutChar(UESC_AD_GetData(1));	 
	
	}
}