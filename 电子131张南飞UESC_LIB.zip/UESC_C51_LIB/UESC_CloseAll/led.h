#include<reg51.h>
void uesc_closeallled(unsigned char IO);

#define P00 0
#define P01 1
#define P02 2  
#define P03 3
#define P04 4
#define P05 5
#define P06 6
#define P07 7


#define P10 10
#define P11 11
#define P12 12
#define P13 13
#define P14 14
#define P15 15
#define P16 16
#define P17 17 

