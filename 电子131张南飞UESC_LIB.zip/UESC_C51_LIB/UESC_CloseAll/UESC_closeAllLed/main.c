#include<reg51.h>
#include "led.h"


unsigned char code table[]={
P00,P01,P02,P03,P04,P05,P06,P07,P10,P11,P12,
P13,P14,P15,P16,P17
};

void main()
{
	unsigned char i;

	while(1)

	{
		for(i=0;i<19;i++);
		table[i];
		
	}
}