#include<reg51.h>
#include "../close LED.h"



void main()
{
 	UESC_closeled(P12); 
}