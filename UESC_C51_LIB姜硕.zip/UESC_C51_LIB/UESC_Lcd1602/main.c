#include<reg52.h>
#include"../UESC_Lcd1602.h"

uchar code table[]={"I will be right here waiting for you!"};


void main()
{
    unsigned char i,j;
	UESC_Lcd1602_Init();
	
	UESC_Lcd1602_write_com(0x80);
	for(i=0;i<16;i++)
	{
		UESC_Lcd1602_write_dat(table[i]);
		delayms(5);
	}
	UESC_Lcd1602_write_com(0x80+0x40);
	for(j=16;j<33;j++)
	{
		UESC_Lcd1602_write_dat(table[j]);
		delayms(5);
	}
	while(1);
}