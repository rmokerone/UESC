#include<reg52.h>
#include<stdio.h>
#include"../UESC_AD.h"
#include"../tubedisplay.h"
void main()
{
	UESC_AD_InitUart();
	UESC_AD_InitADC();
	while(1)
	{
		display(0);
	}
}