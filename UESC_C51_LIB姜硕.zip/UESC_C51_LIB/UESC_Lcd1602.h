#include<reg52.h>
#define uchar unsigned char
#define uint unsigned int
void delayms(uchar xms);
void UESC_Lcd1602_write_com(uchar com);
void UESC_Lcd1602_write_dat(uchar dat);
void UESC_Lcd1602_Init();