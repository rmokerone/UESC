#include<reg52.h>
#include<intrins.h>
typedef unsigned char BYTE;
typedef unsigned int WORD;
sfr CCON=0xd8;
sbit CCF0=CCON^0;
sbit CCF1=CCON^1;
sbit CR=CCON^6;
sbit CF=CCON^7;
sfr CMOD=0xd9;
sfr CL=0xe9;
sfr CH=0xf9;
sfr CCAPM0=0xda;
sfr	CCAP0L=0xea;
sfr CCAP0H=0xfa;
sfr CCAPM1=0xdb;
sfr CCAP1L=0xeb;
sfr CCAP1H=0xfb;
sfr PCAPWM0=0xf2;
sfr PCAPWM1=0xf3;
sbit led1=P1^0;
void UESC_PCA_Capture(char module,char mode);
void UESC_PCA_Capture(char module,char mode);