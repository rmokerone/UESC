/*������Ϊ����ܵ������򣬵���UESC_Tube(unsigned int number)��ʵ������������λ�������������ʾ��
����UESC_TubeDisplay_Bit(char number,char tubebit)��ʵ��ָ��λָ�������룬��ͬ���������¶�������ܶ�ѡ��λѡ��*/
#include"tubedisplay.h"
#include<reg52.h>
sbit wela1=P2^6;
sbit wela2=P2^7;
sbit wela3=P2^4;
sbit wela4=P2^5;
unsigned char code table[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
void delayms(unsigned int xms)
{
	unsigned int i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);
}
char UESC_Tube(unsigned int number)
{	bit flag;
	unsigned char a,b,c,d;
	if(number>9999)
	{
		flag=0;
	}	
	if(number<10000)
	{
		
		flag=1;
		a=number/1000;
		b=number%1000/100;
		c=number%100/10;
		d=number%10;
		UESC_TubeDisplay(a,1);
		UESC_TubeDisplay(b,2);
		UESC_TubeDisplay(c,3);
		UESC_TubeDisplay(d,4);

	}
	return flag;
}
char UESC_TubeDisplay(char number,char tubebit)
{
	unsigned char flag;
	if(number>9)
	{
		flag=0;
	}
	if(number<10)
	{
		flag=1;
		switch (tubebit)
		{
			case 1:
			wela1=0;
			P0=table[number];
			delayms(10);
			wela1=1;
			P0=0xff;
			break;

			case 2:
			wela2=0;
			P0=table[number];
			delayms(10);
		    wela2=1;
			P0=0xff;
			break;

			case 3:
			wela3=0;
			P0=table[number];
			delayms(10);
			wela3=1;
			P0=0xff;

			case 4:
			wela4=0;
			P0=table[number];
			delayms(10);
			wela4=1;
			P0=0xff;
			break;



		}

/*		if(tubebit=1)
		{
			wela1=0;
			P0=table[number];
			delayms(10);
			wela1=1;
			P0=0xff;
		}
		else if(tubebit=2)
		{
			wela2=0;
			P0=table[number];
			delayms(10);
		    wela2=1;
			P0=0xff;
		}
		else if(tubebit=3)
		{
			wela3=0;
			P0=table[number];
			delayms(10);
			wela3=1;
			P0=0xff;
		}
		else
		{
			wela4=0;
			P0=table[number];
			delayms(10);
			wela4=0;
			P0=0xff;
		}					*/
	}
	return flag;
}	
			
char UESC_TubeDisplay_Bit(char number,char tubebit)
{
	unsigned char flag;
	if(number>9)
	{
		flag=0;
	}
	if(number<10)
	{
		flag=1;
		switch (tubebit)
		{
			case 1:
			wela1=0;
			P0=table[number];
			delayms(10);
	//		wela1=1;
			P0=0xff; 
			break;

			case 2:
			wela2=0;
			P0=table[number];
			delayms(10);
	//	    wela2=1;
			P0=0xff; 
			break;

			case 3:
			wela3=0;
			P0=table[number];
			delayms(10);
	//		wela3=1;
			P0=0xff; 
			break;

			case 4:
			wela4=0;
			P0=table[number];
			delayms(10);
	//		wela4=1;
			P0=0xff; 
			break;



		}
		}
	 return flag;
	}		 
