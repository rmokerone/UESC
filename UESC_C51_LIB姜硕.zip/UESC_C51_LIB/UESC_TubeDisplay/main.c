#include"../tubedisplay.h"
#include<reg52.h>
void main()
{
    while(1)
	{
//	UESC_Tube();
	UESC_TubeDisplay_Bit(1,4);
	}
}