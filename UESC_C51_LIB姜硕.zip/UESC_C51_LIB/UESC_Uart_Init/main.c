#include<reg52.h>
#include"../uart_init.h"
void main()
{
	UESC_Uart_Init(9600);
}
