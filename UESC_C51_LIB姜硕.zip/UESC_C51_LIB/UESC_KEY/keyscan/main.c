#include<reg52.h>
#include"../key.h"
void main()
{
	
	if(UESC_TestKey(P32))
	{
		P1=0xfe;
	}	
}