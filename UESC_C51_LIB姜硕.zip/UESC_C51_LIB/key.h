#include<reg52.h>
#define P31 0
#define P32 1
#define P33 2
#define P34 3
sbit a=P3^1;
sbit b=P3^2;
sbit c=P3^3;
sbit d=P3^4;
char UESC_TestKey(unsigned char io);