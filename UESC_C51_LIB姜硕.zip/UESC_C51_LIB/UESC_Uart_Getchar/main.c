#include<reg52.h>
#include"../Uart_Getchar.h"
void main()
{
	unsigned char b;
	b=UESC_Uart_Getchar();		
}