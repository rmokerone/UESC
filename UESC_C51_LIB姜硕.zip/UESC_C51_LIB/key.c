/*������ɼ�����P3^1~��P3^4�Ķ��������Ƿ񱻰��£�ʹ��ʱ����UESC_TestKey(unsigned char io)���ɣ�����ΪP31~P34*/
#include<reg52.h>
#include"../key.h"
unsigned char flag;
void delayms(unsigned char xms)
{
	unsigned i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);	
}
char UESC_TestKey(unsigned char io)
{
	switch(io%10)
	{
		case 0:
			if(a==0)
			{
				delayms(10);	
				if(a==0)
				{
					flag=1;	
				}
			}
			else
					flag=0;
			break;
		case 1:
			if(b==0)
			{
				delayms(10);
				if(b==0)
				{
					flag=1;
				}
			else
					flag=0;
			}
			break;
		case 2:
			if(c==0)
			{
				delayms(10);
				if(c==0)
				{
					flag=1;
				}
			else flag=0;
			}
			break;
		case 3:
			if(d==0)
			{
				delayms(10);
				if(d==0)
				{
					flag=1;
				}		
			}
			else flag=0;
			break;
			
	}
	return flag;	
}