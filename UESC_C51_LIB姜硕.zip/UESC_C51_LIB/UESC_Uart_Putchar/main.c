#include<reg52.h>
#include"../Uart_Putchar.h"
void main()
{
	unsigned char table[]={"hello"};
	UESC_Uart_Putchar(table,5);
}