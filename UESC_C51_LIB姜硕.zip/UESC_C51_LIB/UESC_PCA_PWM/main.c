#include<reg52.h>
#include"../UESC_PCA_PWM.h"
void main()
{
	UESC_PCA_Capture(0,1);
}
void PCA_isr() interrupt 7
{
	CCF0=0;
	led1=!led1;
}

