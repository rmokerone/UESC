#include<reg52.h>
#include"../closeled.h"

unsigned char code table[]={
P00,P01,P02,P03,P04,P05,P06,P07
};

void main()
{
	unsigned char i;
	while(1)
	{
	for(i=0;i<8;i++)
	{
		UESC_CloseLED(table[i]);
	}
	}
}