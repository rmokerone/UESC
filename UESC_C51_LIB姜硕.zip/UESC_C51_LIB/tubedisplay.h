#include<reg52.h>
char UESC_Tube(unsigned int number);
char UESC_TubeDisplay(char number,char tubebit);
char UESC_TubeDisplay_Bit(char number,char tubebit);