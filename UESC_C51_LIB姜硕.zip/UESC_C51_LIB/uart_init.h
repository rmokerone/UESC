#include<reg52.h>
#define fosc 11059200
unsigned char UESC_Uart_Init(unsigned int baud);