#include<reg52.h>
#include<stdio.h>
#include<intrins.h>
typedef unsigned char BYTE;
typedef unsigned int WORD;
void UESC_AD_InitADC();
BYTE UESC_AD_GetData(BYTE ch);
void UESC_AD_GetVol(BYTE ch);
void UESC_AD_InitUart();
float change(BYTE ch);
void delay(WORD n);
void display(BYTE ch);