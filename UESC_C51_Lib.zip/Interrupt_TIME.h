#ifndef __Interrupt_TIME_H__
#define __Interrupt_TIME_H__
#include<reg51.h>
extern unsigned int time,number;
void UESC_TIME_Init(unsigned int TIMEinit);
#endif