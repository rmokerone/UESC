#ifndef __DS18B20_H__
#define __DS18B20_H__
#include<reg51.h>
void UESC_DS18B20_Init();
unsigned char UESC_DS18B20_Read();
void UESC_DS18B20_Write(unsigned char dat);
unsigned int WD_Change();
#endif