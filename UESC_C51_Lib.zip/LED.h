#ifndef __KEY_H__
#define __KEY_H__
#include<reg51.h>
void UESC_CloseLED(unsigned char io);
void UESC_OpenLED(unsigned char io);
#define P00 00							
#define P01 01
#define P02 02
#define P03 03
#define P04 04
#define P05 05
#define P06 06
#define P07 07

#define P10 10
#define P11 11
#define P12 12
#define P13 13
#define P14 14
#define P15 15
#define P16 16
#define P17 17

#define P20 20
#define P21 21
#define P22 22
#define P23 23
#define P24 24
#define P25 25
#define P26 26
#define P27 27

#define P30 30
#define P31 31
#define P32 32
#define P33 33
#define P34 34
#define P35 35
#define P36 36
#define P37 37
#endif			   