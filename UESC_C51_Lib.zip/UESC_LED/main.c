#include<reg51.h>
#include"../LED.h"
void delay()													//��ʱ�Ӻ���
{
	unsigned int i,j;
	for(i=1155;i>0;i--)
	for(j=1053;j>0;j--);
}
/*�򿪵�һλLEDһ��ʱ��󣬹رմ�λLED��������һλ��һֱ�����һλ��*/
void main()
{	UESC_OpenLED(10);delay(); 	UESC_CloseLED(10);delay();
	UESC_OpenLED(11);delay();	UESC_CloseLED(11);delay();	
	UESC_OpenLED(12);delay();	UESC_CloseLED(12);delay();	
	UESC_OpenLED(13);delay();	UESC_CloseLED(13);delay();
	UESC_OpenLED(14);delay();	UESC_CloseLED(14);delay();
	UESC_OpenLED(15);delay();	UESC_CloseLED(15);delay();
	UESC_OpenLED(16);delay();	UESC_CloseLED(16);delay();
	UESC_OpenLED(17);delay();	UESC_CloseLED(17);delay();	
}