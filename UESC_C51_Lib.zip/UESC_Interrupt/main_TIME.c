#include<reg51.h>
#include"../8bitTube.h"
#include"../Interrupt_TIME.h"
void main()
{
	UESC_TIME_Init(50000);
	while(1)
		UESC_TubeDisplay(2,number);
}