#include<reg51.h>
#include"../8bitTube.h"
#include"../Interrupt_Int.h"
void main()
{
	UESC_Int_Init();
	while(1)
	{
		UESC_TubeDisplay(0,number);			
	}
}