#include<reg51.h>
unsigned int time,number,num=0;
void UESC_TIME_Init(unsigned int TIMEinit)
{
	time=TIMEinit;
	EA=1;
	ET0=1;
	TMOD=0x10;
	TH1=(65536-time)/256;
	TL1=(65536-time)%256;
	ET1=1;
	TR1=1;
}
void TIME1() interrupt 3
{
	TH1=(65536-time)/256;
	TL1=(65536-time)%256;
	num++;
	if(num==20)
	{
		num=0;
		number++;
		if(number%100%60==0)
			number+=40;
	}
}