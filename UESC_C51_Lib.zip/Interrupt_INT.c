#include<reg51.h>
unsigned int number=0;
void UESC_Int_Init()
{
	EA=1;
	EX0=1;
	EX1=1;
	IT0=0;
	IT1=0;
	//number=0;
}
void exint0() interrupt 0
{	
	int	i;
	EA=0;
	number++;
	if(number==10000)
		number=0;
	P1=0x00;
	if(INT0==0)
		for(i=50;i>0;i--)
	while(!INT0);
	P1=0xff;
	EA=1;
}
void exint1() interrupt 2
{	
	int	i;
	EA=0;
	number--;
	if(number==-1000)
		number=0;
	P1=0x00;
	if(INT1==0)
		for(i=50;i>0;i--)
	while(!INT1);
	P1=0xff;
	EA=1;
}