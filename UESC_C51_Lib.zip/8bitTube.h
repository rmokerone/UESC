#ifndef __8bitTube_H__
#define __8bitTube_H__
#include<reg51.h>
sbit x1=P2^6;
sbit x2=P2^7;
sbit x3=P2^4;
sbit x4=P2^5;
void delay(unsigned int xms);
char UESC_TubeDisplay(unsigned int point,number);
char UESC_TubeDisplay_Bit(char tubeBit,number);
#endif