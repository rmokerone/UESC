#include <reg51.h>
#include "../8bitTube.h"
void main()
{
	while(1)
	{		
		UESC_TubeDisplay_Bit(1,8);		  //��һλ��ʾ5
		//UESC_TubeDisplay(0,-123);
	}
}