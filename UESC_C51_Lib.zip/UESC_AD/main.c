#include<reg51.h>
#include"../AD.h"
#include"../8bittube.h"
void main()
{
	UESC_AD_Init(0);
	while(1)
	{
		UESC_TubeDisplay(1,UESC_AD_GetData(0));
	}
}