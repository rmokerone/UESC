#ifndef __Interrupt_int_H__
#define __Interrupt_int_H__
#include<reg51.h>
extern unsigned int number;
void UESC_Int_Init();
#endif