#include<reg51.h>
#include"../AD.h"
float result;
int UESC_AD_Init(gall)
{
	TMOD=0x01;				   	//��ʱ��1�Ĺ�����ʽΪ1 
	TH1=(65536-50000)/256;
	TL1=(65536-50000)%256;
	EA=1;						//�����ж�
	ET1=1;						//����ʱ��1�ж�
	TR1=1;						//������ʱ��1
	ADC_RES=0;
	ADC_CONTR=ADC_POWER|ADC_SPEEDLL;
	P1ASF=(1<<gall%10);
	delay(10);
	return 0;	
}
float UESC_AD_GetData(gall)
{
	//float result;
	ADC_CONTR=ADC_POWER|ADC_SPEEDHH|gall|ADC_START;
	delay(1);
	while(!(ADC_CONTR&ADC_FALG));
	{
		ADC_CONTR&=~ADC_FALG;
	}
	//result=((ADC_RES<<2)+ADC_RESLL)*5/1024;
	//result*=1000;
	return result;		 		
}
void timer() interrupt 3				 //��ʱ��1
{	
	int num;
	TH1=(65536-50000)/256;
	TL1=(65536-50000)%256;
	num++;
	if(num==40)
	{
		num=0;
		result=((ADC_RES<<2)+ADC_RESLL)*5/1024;
		result*=1000;		
	}
}