#include<reg51.h>
#include"../DS18B20.h"
#include"../8bitTube.h"
void main()
{
	while(1)
		UESC_TubeDisplay(2,WD_Change());				 
}