#ifndef __UART_H__
#define __UART_H__
#include<reg51.h>
void UESC_UART_Init(unsigned int baud);
char UESC_UART_PutChar(unsigned char c);
char UESC_UART_GetChar();
#endif