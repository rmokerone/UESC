#include<reg51.h>
sbit deep=P2^3;
void main()
{
  deep=0;
}