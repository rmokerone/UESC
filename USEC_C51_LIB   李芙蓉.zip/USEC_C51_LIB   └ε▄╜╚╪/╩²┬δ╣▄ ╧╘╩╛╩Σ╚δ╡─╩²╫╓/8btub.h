#ifndef __8btub_h__
#define __8btub_h__


#include <reg51.h>
#define	uint unsigned int
#define	uchar unsigned char
void uesc_tube_display(unsigned int number);
void delayms(unsigned int xms);


 #endif