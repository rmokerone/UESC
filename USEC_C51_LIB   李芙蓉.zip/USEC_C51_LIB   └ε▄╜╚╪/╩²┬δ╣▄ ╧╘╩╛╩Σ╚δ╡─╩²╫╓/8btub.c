 /*--------------------------------------------------------------------------------------------------------------------------------------
   �������ʾ���������

 ---------------------------------------------------------------------------------------------------------------------------------------*/

#include <reg51.h>
#include "8btub.h"
	
uchar code duanma[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
uchar code weima[]= {0xdf,0xef,0x7f,0xbf};
uchar tubedata[4];

void delayms(uint xms)
{
 uint i,j;
 for(i=xms;i>0;i--)
  for(j=110;j>0;j--);
}

void uesc_tube_display(unsigned int number)
{
	    uchar i;
		tubedata[3]=number%10;
		tubedata[2]=number%100/10;
		tubedata[1]=number%1000/100;
		tubedata[0]=number%10000/1000;
		for(i=0;i<4;i++)
	    {	P2=weima[i];
		    P0=duanma[tubedata[i]];
			delayms(5);
		 }
	
}