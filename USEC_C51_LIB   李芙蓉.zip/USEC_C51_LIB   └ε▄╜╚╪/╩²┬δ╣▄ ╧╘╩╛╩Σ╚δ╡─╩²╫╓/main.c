	 #include<reg51.h>
	 #include"8BTUB.H"
    // sbit key0 = P3^3;

	 unsigned int num ;


	 void main()
	 {
	   while(1)
	   {   
	    
  		 
         uesc_tube_display(1234);
		 
	   
	   }
	 }


