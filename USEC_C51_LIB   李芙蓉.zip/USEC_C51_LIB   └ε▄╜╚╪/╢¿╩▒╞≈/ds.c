#include<reg51.h>
#include"ds.h"
//void delayms(unsigned int xms)
//{
// unsigned int i,j;
// for(i=xms;i>0;i--)
// for(j=110;j>0;j--);
//}

