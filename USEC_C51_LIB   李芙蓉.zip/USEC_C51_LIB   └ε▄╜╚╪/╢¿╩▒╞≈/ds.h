#ifndef __DS_H__
#define __DS_H__


#include<reg51.h>
void delayms(unsigned int xms);

#endif