#include<reg51.h>
#include"ADC.H"
uchar dat;
void InitADC()
{
    P1ASF = 0xf0;                  
    ADC_RES = 0;                
    ADC_CONTR = ADC_POWER | ADC_SPEEDLL| ADC_START|0x07;
    delayms(8); 


}
void InitUart()
{
    TMOD=0x20;
	TH1=0xfd;
	TL1=0xfd;
	TR1=1;
	REN=1;
	SM0=0;
	SM1=1;
	REN=1;
	EA=1;
	ES=1;  


    while(1);

}

void Senddata()
{
  
  while(!TI)
  TI=0;
  
  //SBUF=dat;
  SBUF=0X55;
     
    //ADC_CONTR = ADC_POWER | ADC_SPEEDLL| ADC_START|0x07;

}

void delayms(uint xms)
{
 uint i,j;
 for(i=xms;i>0;i--)
  for(j=110;j>0;j--);
}

void ck()interrupt 4
{
 	ADC_CONTR &=!ADC_FLAG;
    RI=0;
    dat=ADC_RES;
    //dat=SBUF;
	//ADC_CONTR = ADC_POWER | ADC_SPEEDLL| ADC_START|0x07;
 	

}


unsigned int GetADCResult()
{
	
    ADC_CONTR = ADC_POWER | ADC_SPEEDLL |ADC_FLAG| ADC_START|0x07;
    _nop_();                        //�ȴ�4��NOP
    _nop_();
    _nop_();
    _nop_();
     IE=0xa0;                //ʹ��ADC�ж�
   while (!(ADC_CONTR & ADC_FLAG));//�ȴ�ADCת�����
    ADC_CONTR &= ~ADC_FLAG;         //Close ADC
 
    return ADC_RES;                 //����ADC���
}



