#include<reg51.h>
#include"reg51.h"
void DS18b20_readtemperture();
void DS18b20_display();
void DS18b20_display();






void main()
{
	while(1)
	{
	DS18b20_readtemperture();
	DS18b20_display();
	DS18b20_display();
	}
}



