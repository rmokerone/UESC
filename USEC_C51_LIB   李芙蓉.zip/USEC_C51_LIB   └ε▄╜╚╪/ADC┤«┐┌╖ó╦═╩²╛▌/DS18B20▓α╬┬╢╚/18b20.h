#ifndef __18B20_H__
#define __18B20_H__


#include<reg51.h>
#define uint unsigned int
#define uchar unsigned char

sbit dat=P2^2;

uchar DS18b20_read();
void DS18b20_init();
void delay(uint);
void DS18b20_display();
void DS18b20_readcom();
void DS18b20_changecom();
void DS18b20_write(uchar byte);
void DS18b20_readtemperture();

#endif