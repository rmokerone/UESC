#include<reg51.h>
#include"18b20.h"
unsigned char code shu[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
unsigned char code weima[]= {0xdf,0xef,0x7f,0xbf};
 

int temp;

void delay(uint ms)
{
	uint i,j;
	for(i=ms;i>0;i--)
		for(j=1000;j>0;j--);
}


void DS18b20_init()
{
	uint i;
	dat=0;
	i=600;		  //��ʱ600us
	while(i>0)
		i--;
	dat=1;
	while(dat);
	i=100;
	while(i>0)
		i--;
	dat=1;
}	


void DS18b20_changecom()
{
	 DS18b20_init();
	delay(1);
	DS18b20_write(0xcc);	  //����ROM����ָ��
    DS18b20_write(0x44);	  //�¶�ת��ָ��
//	delay(100);
}

void  DS18b20_readcom()
{
	DS18b20_init();
	delay(1);
	DS18b20_write(0xcc);
    DS18b20_write(0xbe);   //���Ͷ�ȡ�¶ȵ�ָ��
}


void DS18b20_write(uchar byte)
{
	uint i,j;
	for(j=0;j<8;j++)
	{
		dat=0;
		i=15;		   //��ʱ15us
		while(i--);
		dat=byte&0x01;
		i=30;		   //��ʱ30us
		while(i--);
		dat=1;
		byte>>=1;
	}
}


uchar DS18b20_read()
{
	uchar byte,bi;
	uint i,j;
	for(j=8;j>0;j--)
	{
		dat=1;		//��ʱ2us
		i++;
		dat=0;		//�ӳ�6us
		i=6;
		while(i--);   
		dat=1;		//�ӳ�4us
		i=4;		  
		while(i--); 
		bi=dat;
		byte=(byte>>1)|(bi<<7);
		i=30;
		while(i--);
	}
	return byte;		
}

void DS18b20_readtemperture()
{
	uchar a,b;		
    DS18b20_changecom();	  
    DS18b20_readcom();		
	a=DS18b20_read();						
	b=DS18b20_read();		  	
	
	temp=b;		  
	temp<<=8;		
	temp|=a;	 
	temp=temp*(6.25)+0.05;
	

}
 
void DS18b20_display()
{
	   unsigned char i, tubedata[4];
//		 t=t*(6.25)+0.25;
      
	  	tubedata[0]=temp%10;
		tubedata[1]=temp%100/10;
		tubedata[2]=(temp%1000/100)|0x80;
		tubedata[3]=temp/1000;
		for(i=0;i<4;i++)
	    {	
		    P2=weima[i];
		    P0=shu[tubedata[i]];
			delay(2);																  
	    }
		
}
