#include<reg51.h>
#include"ADC.H"
  extern uchar dat;
 void main()
{
 // unsigned int GetADCResult();
  InitADC();
  InitUart();
  IE=0xa0;
  while(1)
  {
    Senddata();
  }		   
}