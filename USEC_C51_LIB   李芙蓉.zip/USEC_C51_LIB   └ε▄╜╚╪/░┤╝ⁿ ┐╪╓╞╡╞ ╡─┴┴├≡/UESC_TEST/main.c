#include<reg51.h>
#include "KEY.H"
void main()
{
	while(1)
	{
		 if(USEC_TESTKEY(P32))
		 P1=0X00;
	}
}