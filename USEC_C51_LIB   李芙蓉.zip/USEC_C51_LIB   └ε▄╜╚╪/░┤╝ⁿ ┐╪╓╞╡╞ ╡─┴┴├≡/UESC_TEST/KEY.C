#include<reg51.h>						  
#include "KEY.H" 
  
void delayms(unsigned int xms)
{
	unsigned int i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);
}

char USEC_TESTKEY(unsigned char IO)
{
  		switch(IO/10)
        {
	    	case 0:
				if(!(P0&(1<<IO%10)))
				{
					delayms(10);
					
					return 1;
				}
				break;
			 
			
	    	case 1:
				if(!(P1&(1<<(IO%10))))  
				{
					delayms(10);
					
					return 1;
				}
				break;
				
	    	case 2:
				if(!(P2&(1<<(IO%10))))
				{
					delayms(10);
					
					return 1;
				}
				break;
				
	    	case 3:
				if(!(P3&(1<<(IO%10))))
				{
					delayms(10);
					
					return 1;
				}
				break;	   
		}
		return 0;	
}		
			