		#include<reg51.h>
		#include"UART.H"
		
		void main()
		{
		 while(1)
		 {
		 	  UESC_UART();
		 }
		
		}