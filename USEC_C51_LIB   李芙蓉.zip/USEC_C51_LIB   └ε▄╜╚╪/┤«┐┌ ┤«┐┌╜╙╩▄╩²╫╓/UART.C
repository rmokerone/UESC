	    #include<reg51.h>
		#include"UART.H"
 // unsigned char code table[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
  //unsigned char code table0[]={0xdf,0xef,0x7f,0xbf};
  unsigned char a,flag;
  void UESC_UART()
  {
  	TMOD=0x20;
	TH1=0xfd;
	TL1=0xfd;
	TR1=1;
	SM0=0;
	SM1=1;
	REN=1;
	EA=1;
	ES=1;  
//	P2 = 0xdf;
    while(1)
	{
	 if(flag==1)
	 {	
	 ES=0;
	 SBUF=a;
	 while(!TI);
	 TI=0;
     
	 ES=1;
	 flag=0;
	 }	 
	}

	
	}
  
  
  void CK() interrupt 4
  {	
  	RI=0;
  	a=SBUF;
//	P0=table[a];
	flag=1;


  
  
  }
