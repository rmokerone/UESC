   	#include<reg51.h>
	#include"zd.h"
	unsigned char code table[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
	unsigned char code table0[]={0xdf,0xef,0x7f,0xbf};

void delayms(unsigned int xms)
{
 unsigned int i,j;
 for(i=xms;i>0;i--)
 for(j=110;j>0;j--);
}


void zd() interrupt	0
{    
   unsigned int i;
  
   while(1)
   {
     for(i=0;i<10;i++)
	 {
   	 P2=table0[i];
	 P0=table[i];
   	 delayms(1000);
	  
	    P1=0x00;
		delayms(50);
		P1=0xaa;
		delayms(50);
   	  }
   
   }






}