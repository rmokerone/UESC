#include<reg51.h>						  
#include <KEY.H> 
unsigned char flag;
void delayms(unsigned int xms)
{
	unsigned int i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);

}



unsigned char USEC_TESTKEY(unsigned char IO)
{
  		switch(IO%10)
        {
	    	case 0:
				if(a==0)
				{
					delayms(10);
					if(a==0)
					flag=1;
				}
				else 
					flag=0;
			break;
			   	case 1:
				if(b==0)
				{
					delayms(10);
					if(b==0)
					flag=1;
				}
				else 
					flag=0;
			break;

		 			case 2:
				if(c==0)
				{
					delayms(10);
					if(c==0)
					flag=1;
				}
				else 
					flag=0;
			break;
					case 3:
				if(d==0)
				{
					delayms(10);
					if(d==0)
					flag=1;
				}
				else 
					flag=0;
			break;
	  
	  }
 
 	 return flag;
 }								