#include<reg51.h>
#include <KEY.H>
void main()
{
	while(1)
	{
		 UESC_TESTKEY(P3^1);
	}
}