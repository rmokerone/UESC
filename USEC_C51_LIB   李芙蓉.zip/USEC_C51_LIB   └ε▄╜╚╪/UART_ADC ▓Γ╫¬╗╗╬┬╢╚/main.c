 #include<reg51.h>
#include"ADC.H"
extern unsigned int result;

void main()
{
   
    InitADC();
                      //��ʼ��ADC
	IE = 0xa0;

    while (1)
    {

     //result = GetADCResult(); 
	 uesc_tube_display(result) ;
	          
    }
}




