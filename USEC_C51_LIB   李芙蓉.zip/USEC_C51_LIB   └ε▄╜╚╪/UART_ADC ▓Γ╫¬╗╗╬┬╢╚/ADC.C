#include<reg51.h>
#include"ADC.H"
#include<intrins.h>
uchar code duanma[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
uchar code weima[]= {0xdf,0xef,0x7f,0xbf};
uchar tubedata[4];

  unsigned int result,i;

//  sbit led = P1^0;
  //BYTE ch=0;
//unsigned int GetADCResult()
//{
//	
//    ADC_CONTR = ADC_POWER | ADC_SPEEDLL |ADC_FLAG| ADC_START|0x01;
//    _nop_();                        //�ȴ�4��NOP
//    _nop_();
//    _nop_();
//    _nop_();
//                     //ʹ��ADC�ж�
//   while (!(ADC_CONTR & ADC_FLAG));//�ȴ�ADCת�����
//    ADC_CONTR &= ~ADC_FLAG;         //Close ADC
// 
//    return ADC_RES;                 //����ADC���
//}											  



void InitADC()
{
    P1ASF = 0x01;                   //����P1��ΪAD��
    ADC_RES = 0;
	ADC_RESL=0;                    //�������Ĵ���
    ADC_CONTR = ADC_POWER | ADC_SPEEDLL| ADC_START|0x00;
    delayms(8);                       //ADC�ϵ粢��ʱ
	
}




/*----------------------------
������ʱ
----------------------------*/
void delayms(uint xms)
{
 uint i,j;
 for(i=xms;i>0;i--)
  for(j=110;j>0;j--);
}


void uesc_tube_display(uint number)
{

	    uchar i;
		tubedata[0]=number%10;
		tubedata[1]=number%100/10;
		tubedata[2]=number%1000/100;
		tubedata[3]=number/1000;
		for(i=0;i<4;i++)
	    {	
		    P2=weima[i];
			
		    P0=duanma[tubedata[i]];
			delayms(5);	
			
																  
	    }
	
}
  void zd()interrupt 5 using 1
  {	 
	unsigned int dat;
    
//   	led = 0;
  	ADC_CONTR &=!ADC_FLAG; //�������Ĵ���
	dat=(ADC_RES<<2|ADC_RESL);
    result=dat*5/1000;
	
	//ADC_CONTR = ADC_POWER | ADC_SPEEDLL| ADC_START|0x00;
   
  	
  }