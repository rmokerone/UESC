
#include<reg51.h>
#include"PWM.H"
#include "8btub.h"
extern unsigned int CAP_Length; 
 void main()
 {
   
    ACC = P_SW1;
    ACC &= ~(CCP_S0 | CCP_S1);      //CCP_S0=0 CCP_S1=0
    P_SW1 = ACC;      
    PCA_CaptureModeInit();
	
	TMOD = 0x20;
	TH0 = 0xfe;
	TL0 = 0xfe;
	TR0 = 1;
	ET0 = 1;
  

  while(1)
  {	 	  
	  Plus = 1;
      uesc_tube_display(CAP_Length);

	  Plus = 0;
	 // uesc_tube_display(CAP_Length);
	  
  }

}

