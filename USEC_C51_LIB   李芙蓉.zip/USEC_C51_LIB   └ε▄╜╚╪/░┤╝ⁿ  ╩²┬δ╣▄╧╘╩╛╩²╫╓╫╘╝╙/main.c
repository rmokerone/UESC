			  	 #include<reg51.h>
	 #include"8BTUB.H"
     sbit key0 = P3^3;

	 unsigned int num = 0;

	 void Key()
	 {
	      if(key0 == 0)
		  {
		       delayms(10);
			   if(key0 == 0)
			   {
			        num ++;
				
					if(num >= 9999)
					num = 0;
			   }
		  }
	 }
	 void main()
	 {
	   while(1)
	   {   
	    
  		 Key();
         uesc_tube_display(num);
		 
	   
	   }
	 }
