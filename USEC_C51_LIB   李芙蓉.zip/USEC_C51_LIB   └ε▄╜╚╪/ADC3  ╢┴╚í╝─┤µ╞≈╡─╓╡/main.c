 #include<reg51.h>
#include"ADC.H"
unsigned int  re;
unsigned char k;
void main()
{
    initds(); // ��ʱ���ĳ�ʼ��     

    InitADC(); //  ADC�ĳ�ʼ��
    while (1)
    {

	 uesc_tube_display(re) ;
    }
}

void T1_time() interrupt 3
{
	  
	 TH1=(65536-50000)/256;	//��װ��ֵ
     TL1=(65536-50000)%256;
	  	 k++;
      if(k==20)
  {
       k=0;
       re =	GetADCResult(); 

  }

}										  
