    /*----------------------------------------------------------------------------------------------------------------------------
   	ADC ��ȡ�Ĵ�����ֵ
   	------------------------------------------------------------------------------------------------------------------------*/


	#include<reg51.h>
	#include"ADC.H"
	sbit led=P2^0;
	unsigned int  result;
	uchar code duanma[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
    uchar code weima[]= {0xdf,0xef,0x7f,0xbf};
    uchar tubedata[4];
	unsigned int result;
	void InitADC()
	{
	   P1ASF = 0xff;                   //����P1��ΪAD��
       ADC_RES = 0;
       ADC_RESL=0;                    //�������Ĵ���
    	ADC_CONTR = ADC_POWER | ADC_SPEEDLL ;
       delayms(8);                       //ADC�ϵ粢��ʱ
	
	
	
	
	}
	


/*----------------------------
������ʱ
----------------------------*/
void delayms(uint xms)
{
 uint i,j;
 for(i=xms;i>0;i--)
  for(j=110;j>0;j--);
}


void uesc_tube_display(uint number)
{

	    uchar i;
		tubedata[0]=number%10;
		tubedata[1]=number%100/10;
		tubedata[2]=number%1000/100;
		tubedata[3]=number/1000;
		for(i=0;i<4;i++)
	    {	
		    P2=weima[i];
			
		    P0=duanma[tubedata[i]];
			delayms(5);	
			
																  
	    }
	
}



unsigned int GetADCResult()
{
    
    unsigned int dat;
	ADC_CONTR = ADC_POWER | ADC_SPEEDLL | ADC_START |0x00;
    _nop_();                        //�ȴ�4��NOP
    _nop_();
    _nop_();
    _nop_();
   while (!(ADC_CONTR & ADC_FLAG));//�ȴ�ADCת�����
   	ADC_CONTR &=!ADC_FLAG;
	dat=(ADC_RES<<2|ADC_RESL);
    result=dat*5;
    return result;                 //����ADC���
}	


void initds()
{
  TMOD=0x01;
  TH1=(65536-50000)/256;   //װ��ֵ
  TL1=(65536-50000)%256;
  ET1=1;
  TR1=1;
  EA=1;


}



