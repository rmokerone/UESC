  #include<reg51.h>
  unsigned char code table[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
  unsigned char code table0[]={0xdf,0xef,0x7f,0xbf/*,0xdf,0xef,0x7f,0xbf,0xdf,0xef*/};
  unsigned char a,num=0,flag;
  void main()
  {
  	TMOD=0x20;
	TH1=0xfd;
	TL1=0xfd;
	TR1=1;
	SM0=0;
	SM1=1;
	REN=1;
	EA=1;
	ES=1;  
    P2=0xdf;
    while(1)
	{
	  
	  if(a==1)
	  {
	   P0=table[num];
	   num++;
	   if(num==10)
	   num=0;
	 
	  

	  }
	}
  }
	
	
  
  
  void CK() interrupt 4
  {	
  	RI=0;
  	a=SBUF;

	

  
  
  }