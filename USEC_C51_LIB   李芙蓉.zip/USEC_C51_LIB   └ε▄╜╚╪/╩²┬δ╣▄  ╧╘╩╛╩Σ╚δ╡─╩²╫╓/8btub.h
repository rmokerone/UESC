#include <reg51.h>
#define	uint unsigned int
#define	uchar unsigned char
uchar uesc_tube_display(uint number);
void delayms(uint xms);