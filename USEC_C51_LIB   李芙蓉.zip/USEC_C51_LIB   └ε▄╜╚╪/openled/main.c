			#include<reg51.h>
 #include"LED.H"

 void main()
  {
    USEC_openled(P10);
  }
			
	