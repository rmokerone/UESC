			  

	  
	 #include<reg51.h>
	 #include"LED.H"
			
	 void USEC_openled (unsigned char IO)

														 
	 {
	 switch(IO/10)
	 {
	  case 0:P0=~(1<<IO%10);break;
	  case 1:P1=~(1<<IO%10);break;
	  case 2:P2=~(1<<IO%10);break;
   
	  case 3:P3=~(1<<IO%10);break;


	 
	 
	 
	 }
	 }