#include<reg51.h>
#include"../capture.h"
void main()
{
	UESC_PCA_capture(1,0);
	while(1);
}