#ifndef __Time_H__
#define __Time_H__
#include<reg51.h>
#define  uint   unsigned int
#define  uchar  unsigned char
sbit DQ=P2^2;
sbit bell=P3^0;
void UESC_Temperature_Init();
void Temperature_writeByte(unsigned char dat);
unsigned char Temperature_readbit();
unsigned char readByte();
void Temperature_sendChangeCmd();
void Temperature_sendReadCmd();
unsigned int get_Temperature_value();
#endif