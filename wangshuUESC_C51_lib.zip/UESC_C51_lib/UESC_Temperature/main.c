#include<reg51.h>
#include"../Temperature.h"
#include"../8bitTube.h"
void main()
{
	while(1) //�����¶�ת��
	{
		UESC_TubeDisplay(get_Temperature_value(),2);
		if(UESC_TubeDisplay(get_Temperature_value(),2)>30)
		{bell=1;}
		else
		{bell=0;}
	}
}