#include<reg51.h>
#include"../key.h"
#include"../8bitTube.h"
#define uint unsigned int
#define uchar unsigned char
uchar num=0;
void main()
{
	while(1)
	{
	UESC_TubeDisplay(num,4);
	
	 {
	 delayms(100);
	 if(UESC_TestKEY(31)==1)
	 {
	  num++;
	  if(num==1000)
	 {num=0;}
	 }
	 while(UESC_TestKEY(31));
	 }	
	 }

}




