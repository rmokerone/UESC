#include<reg52.h>
sbit key1=P3^1;
sbit s=P2^5;
int code table[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
int n=0;
void delayms(int xms)
{
  int i,j;
  for(i=xms;i>0;i--)
  for(j=110;j>0;j--);
}
void main()
{	  
	s=0;
	P0 = 0x05;
	while(1)
	{
	if(key1==0)
	{
		delayms(10);
		if(key1==0)
		{
		
			n++;
			P0=table[n];
			while(!key1);
			
		}  
	}
	}
}