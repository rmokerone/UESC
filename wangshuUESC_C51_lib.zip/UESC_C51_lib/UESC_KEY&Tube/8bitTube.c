#include"8bitTube.h"
unsigned char code table[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
void delayms(unsigned int xms)
{
  unsigned int i,j;
  for(i=xms;i>0;i--)
  for(j=110;j>0;j--);
}
char UESC_TubeDisplay(unsigned int number)
{
   unsigned int a,b,c,d;
   if(number<=9999)
   {
     a=number/1000;
	 b=number%1000/100;
	 c=number%100/10;
	 d=number%10;
	 x1=0;P0=table[a];delayms(10);x1=1;
	 x2=0;P0=table[b];delayms(10);x2=1;
	 x3=0;P0=table[c];delayms(10);x3=1;
	 x4=0;P0=table[d];delayms(10);x4=1;
	 return 1;
   }
	else return 0;    	
}
char UESC_TubeDisplay_Bit(char number,char Tubebit)	
{
	 if(0<Tubebit&&Tubebit<=4)
	{
	 	if(0<=number&&number<=9)
	  {
	  	if(Tubebit==1)
		{x1=0;P0=table[number];delayms(10);x1=1;}
		if(Tubebit==2)
		{x2=0;P0=table[number];delayms(10);x2=1;}
		if(Tubebit==3)
		{x3=0;P0=table[number];delayms(10);x3=1;}
		if(Tubebit==4)
		{x4=0;P0=table[number];delayms(10);x4=1;}

   		}
	}
	return 0;
} 			