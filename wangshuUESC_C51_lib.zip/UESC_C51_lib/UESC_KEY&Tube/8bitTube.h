#ifndef __TUBE_H__
#define __TUBE_H__
#include<reg52.h>
void delayms(unsigned int xms);
char UESC_TubeDisplay(int number,char point);
char UESC_TubeDisplay_Bit(char number,char Tubebit);
sbit  x1=P2^6;
sbit  x2=P2^7;
sbit  x3=P2^4;
sbit  x4=P2^5;
#endif