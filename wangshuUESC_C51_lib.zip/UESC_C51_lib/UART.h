#ifndef __TUBE_H__
#define __TUBE_H__
#include<reg51.h>
char UESC_UART_Init(unsigned int baud);
char UESC_UART_Getchar(void);
char UESC_UART_Putchar(unsigned char c);
#endif

