#ifndef __AD_H__
#define __AD_H__
#include<reg51.h>
void delayms(unsigned int xms);
int UESC_AD_Init(gall);
int UESC_AD_Getdata(gall);
int UESC_AD_GetVol();
sfr ADC_CONTR=0xBC;
sfr ADC_RES=0xBD;
sfr ADC_RESL=0xBE;
sfr P1ASF=0x9D;
#define ADC_POWER 0x80
#define ADC_FLAG 0x10
#define ADC_START 0x08
#define	ADC_STOP	0xf7
#define ADC_SPEEDLL 0x00
#define ADC_SPEEDL 0x20
#define ADC_SPEEDH 0x40
#define ADC_SPEEDHH 0x60
#define CHS2		2
#define CHS1 		1
#define CHS0		0
#define CHS3		3
#define uint unsigned int
#define uchar unsigned char
#endif						