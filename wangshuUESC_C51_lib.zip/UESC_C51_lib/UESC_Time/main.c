#include<reg51.h>
#include"../Time.c"
void main()
{
	UESC_Time_Init();
	while(1);
 /*	{
		if(num==20)
		{
			num=0;
			led1=~led1;
		}
	} */
}