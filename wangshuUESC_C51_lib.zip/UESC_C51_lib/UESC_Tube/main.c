#include<reg51.h>
#include"../8bitTube.h"
void main()
{  
	while(1)
	{
		UESC_TubeDisplay(2133,4);
	//	delayms(100);
	//	UESC_TubeDisplay_Bit(3,4);	
	}
}