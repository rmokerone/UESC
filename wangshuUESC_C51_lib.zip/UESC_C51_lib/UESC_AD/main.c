#include<reg51.h>
#include"../AD.h"
#include"../8bittube.h"
unsigned int temp;	
void main()
{
	uint temp = 0 ,i;
	 UESC_AD_Init(1);
	 while(1)				   
	 {
		UESC_TubeDisplay(UESC_AD_Getdata(1),1);
		delayms(50);
	 }
}