#include<reg51.h>
#include"../PWM.h"
void main()
{
	UESC_PCA_PWM(1,100);//width�ķ�ΧΪ0~255
	while(1);
}