#include<reg51.h>
#include"../LED.h"
#define uint unsigned	int
void delayms()
{
  uint i,j;
  for(i=1000;i>0;i--)
  for(j=110;j>0;j--);
} 
void main()
{
 UESC_OpenLED(10);delayms();//���ô򿪵Ƶĺ���
 UESC_OpenLED(11);delayms();	  
 UESC_OpenLED(12);delayms();	    
  UESC_CloseLED(12);delayms();//���ùرյƵĺ���
  UESC_CloseLED(11);delayms();
  UESC_CloseLED(10);delayms();
 }