#ifndef __Time_H__
#define __Time_H__
#include<reg51.h>
sbit led1=P1^0;
void UESC_Time_Init();
#endif