#ifndef __AD_H__
#define __AD_H__
#include<reg51.h>
void UESC_Interrupt_Init();
#define IE 0x9c
#define P10 10
#endif