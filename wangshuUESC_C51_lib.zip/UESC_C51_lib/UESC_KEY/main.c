#include<reg51.h>
#include"../KEY.h"
#define uint unsigned int
sbit LED1=P1^0;
sbit LED2=P1^2;
sbit LED3=P1^4;
sbit LED4=P1^6;
void delayms(uint xms)//��ʱ�Ӻ���
{
  uint i,j;
  for(i=xms;i>0;i--)
  for(j=110;j>0;j--);
}
void main()
{
  LED1=!UESC_TestKEY(31);delayms(100);//�ð������Ƶ���
  LED2=!UESC_TestKEY(31);delayms(100);
  LED3=!UESC_TestKEY(32);delayms(100);
  LED4=!UESC_TestKEY(32);delayms(100);

}