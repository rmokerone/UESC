#include<reg51.h>
#include"../Interrupt.h"
sbit a=P0^4;
void delayus(unsigned int xus)
{
  unsigned int i,j;
  for(i=xus;i>0;i--)
  for(j=110;j>0;j--);
}
void main()
{  P1=0xff;
 UESC_Interrupt_Init();
	while(1)
	{
	  a=1;	  delayus(10);
	  a=0;	  delayus(10);//��ʱʱ�䲻�ܳ�

	}

}