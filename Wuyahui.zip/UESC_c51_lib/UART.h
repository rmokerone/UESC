#ifndef __UART_H_
#define __UART_H_
#include<reg51.h>
#define uchar unsigned char
#define uint unsigned int
void UESC_UART_Init(uint);
void UESC_UART_Getchar(void);
void UESC_UART_Putchar(uchar);
#endif