#ifndef __AD_H_
#define __AD_H_
#include<STC12C5A40S2.h>
#define uint unsigned int
#define uchar unsigned char
void UESC_AD_Init(int);
uint UESC_AD_GetData(int);
void ADC_VolDisplay();
void delay(uint);

#endif