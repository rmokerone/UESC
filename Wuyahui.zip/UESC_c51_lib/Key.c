#include"Key.h"
char UESC_TestKey(unsigned char IO)
{
	char k=0;
	switch(IO/10)
	{
		case 3:if(!(P3&(1<<(IO%10))))		 //��1���ƣ�IO��10ȡ�ࣩλ	�ٺ�P3����	ȡ��
			   {
				   	delayms(10);			 //ȥ����ʱ
					if(!(P3&(1<<(IO%10))))
					{
						while(!(P3&(1<<(IO%10))));
						k=1;
					}
				   	
			   }
			   	break;		   
	}
	return k;
}

void delayms(uint z)
{
	uint x,y;
	for(x=z;x>0;x--)
		for(y=110;y>0;y--);
}



