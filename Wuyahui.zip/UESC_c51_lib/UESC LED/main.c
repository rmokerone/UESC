#include<reg51.h>
#include"../LED.h"
delay(int);
void main()
{
	UESC_OpenLED(P11);
	delay(500);
	UESC_CloseLED(P10);
	delay(500);

}
delay(int z)
{
	int x,y;
	for(x=z;x>0;x--)
		for(y=110;y>0;y--);
}