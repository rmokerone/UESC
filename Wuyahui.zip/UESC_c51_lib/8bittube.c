#include"8bittube.h"

unsigned char code shu[]=
{
0x05,0x7d,0x46,0x54,0x3c,
0x94,0x84,0x5d,0x04,0x14
};

unsigned char code dian[]=
{
0x01,0x79,0x42,0x50,0x38,
0x90,0x80,0x59,0x00,0x10
};
/*******************������ʾ����**********************/
char n1,n2,n3,n4;
void delay(unsigned int);
char UESC_TubeDisplay(unsigned int number)
{
	if(number<=9999)
	{
		n1=number/1000;
		n2=number/100%10;
		n3=number/10%10;
		n4=number%10;
	
		x1=0;	P0=shu[n1];			delay(10);	x1=1;
		x2=0;	P0=dian[n2];		delay(10);	x2=1;
		x3=0;	P0=shu[n3];			delay(10);	x3=1;
		x4=0;	P0=shu[n4];			delay(10);	x4=1;
	
	}
	else
	return 0;
	
}

/******************************�ɰ�λ��ʾ����********************************/
char UESC_TubeDisplay_Bit(char number,char tubeBit)
{
	if(number<=9&&tubeBit<5)	
	{
		switch(tubeBit)
		{
			case 1:x1=0;	P0=shu[number];		delay(10);	x1=1; 	break;
			case 2:x2=0;	P0=shu[number];		delay(10);	x2=1; 	break;
			case 3:x3=0;	P0=shu[number];		delay(10);	x3=1; 	break;
			case 4:x4=0;	P0=shu[number];		delay(10);	x4=1; 	break;
		}	
	}
	else
		return 0;
}

void delay(unsigned int z)
{
	int x,y;
	for(x=z;x>0;x--)
		for(y=110;y>0;y--);
}