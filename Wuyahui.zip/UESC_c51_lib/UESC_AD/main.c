#include<STC12C5A40S2.H>
#include<../AD.h>

int vol;
void main()
{
	int k;
	UESC_AD_Init(0xff);
	while(1)
	{
		UESC_AD_GetData(0x00);
		for(k=0;k<35;k++)
			ADC_VolDisplay();	
	}
}