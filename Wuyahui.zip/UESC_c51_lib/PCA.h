#ifndef __PCA_h__
#define __PCA_h__
#include "STC12C5A40S2.h"

#define uint unsigned int 
#define uchar unsigned char
void UESC_PCA_capture(char,uchar );
void UESC_PCA_pwm(char,uchar);

#endif