#include<reg51.h>
#ifndef __Key_H__
#define __Key_H__
#define uint unsigned int
void delayms(uint);
char UESC_TestKey(unsigned char);
#define P31 31
#define P32 32
#define P33 33
#define P34 34
#endif
