#include"../PCA.h"

uchar a;
void delay(int);
void main()
{
	a=0;
	while(1)
	{
		UESC_PCA_pwm(1,a);
		a++;
		delay(50);
		if(a==255)
			a=0;
	
	}		
}

void delay(int z)
{
	int x,y;
	for(x=z;x>0;x--)
		for(y=110;y>0;y--);
}			  
