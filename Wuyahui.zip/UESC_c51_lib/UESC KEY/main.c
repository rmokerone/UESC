#include<reg51.h>
#include"../Key.h"
#define uchar unsigned char

sbit x1=P2^6;
sbit x2=P2^7;
sbit x3=P2^4;
sbit x4=P2^5;

uchar code dian[]=
{
0x01,0x79,0x42,0x50,0x38,
0x90,0x80,0x59,0x00,0x10
};

uchar code shu[]=
{
0x05,0x7d,0x46,0x54,0x3c,
0x94,0x84,0x5d,0x04,0x14
};
uint n,n1,n2,n3,n4,n5,n6;
uchar lamp;                                                                                                                                                                                                                                                                                                                             

void delayms(uint);
void display();
void keyscan();

void main()
{
	TMOD=0x01;
	TH0=(65536-10000)/256;
	TL0=(65536-10000)%256;
	EA=1;
	ET0=1;
	TR0=0;
	while(1)
	{
		display();
		keyscan();
	}	
}

void display()
{
	n1=n5/1000;
	n2=n5/100%10;
	n3=n5/10%10;
	n4=n5%10;

	x1=0;	P0=shu[n1];		delayms(10);	x1=1;
	x2=0;	P0=dian[n2];	delayms(10);	x2=1;
	x3=0;	P0=shu[n3];		delayms(10);	x3=1;
	x4=0;	P0=shu[n4];		delayms(10);	x4=1;

}


void T0_time()interrupt 1
{
	TH0=(65536-5000)/256;
	TL0=(65536-5000)%256;
	n++;
	if(n==2)
	{
		n=0;
		n5++;
		if(n5==6000)
		{
			n5=0;
			TR0=0;
		}
	}
}

void keyscan()
{
	if(UESC_TestKey(P32))
	{
		TR0=~TR0;
	}
	
	if(UESC_TestKey(P31))
	{
		n5=0;
		TR0=0;
	}	
}