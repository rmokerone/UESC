#include<reg51.h>
#ifndef __LED_H__
#define __LED_H__
void UESC_CloseLED(unsigned char);
void UESC_OpenLED(unsigned char);		 
#define P10 10
#define P11 11
#define P12 12
#define P13 13
#define P14 14
#define P15 15
#define P16 16
#define P17 17
#endif
