#ifndef __Tube_H__
#define __Tube_H__
#include<reg51.h>
sbit x1=P2^6;
sbit x2=P2^7;
sbit x3=P2^4;
sbit x4=P2^5;
char UESC_TubeDisplay(unsigned int);
char UESC_TubeDisplay_Bit(char,char);
#endif


