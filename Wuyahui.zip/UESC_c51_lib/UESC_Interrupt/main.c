#include"..\interrupt.h"

uchar a,k;
void delay(uint);

void main()
{
	UESC_T0Init(3); 
	while(1)
	{
		k++;
		delay(30);
	}
}


void UESC_T0()interrupt 1
{
	TH0=(65536-3)/256;
	TL0=(65536-3)%256;
	a++;
	if(a<=k)
		P1=0x00;
	else
		P1=0xff;
	
}

void delay(uint z)
{
	int x,y;
	for(x=z;x>0;x--)
		for(y=110;y>0;y--);
}