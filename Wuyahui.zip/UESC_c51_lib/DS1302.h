#ifndef __DS1302_H__
#define __DS1302_H_
#include<reg51.h>

sbit sclk=P3^5;
sbit data_io=P3^6;
sbit rst=P3^7;

#define uchar unsigned char
void write(uchar,uchar);
uchar read(uchar);
void delayms(uint);
#endif  