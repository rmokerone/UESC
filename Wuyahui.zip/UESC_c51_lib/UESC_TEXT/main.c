#include<reg51.h>
#include"../8bittube.h"
#include"../Key.h"
unsigned int number;
char num,tubeBit;
main()
{
	num=0,tubeBit=1;
	while(1)
	{



		 if(UESC_TestKey(32))
		 {
		 	num++;
			if(num>9)
				num=0;
		 }

		 if(UESC_TestKey(33))
		 {
		 	tubeBit++;
			if(tubeBit>4)
				tubeBit=1;		
		 }
		 UESC_TubeDisplay_Bit(num,tubeBit);

	}
}