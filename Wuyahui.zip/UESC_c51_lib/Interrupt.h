#ifndef __Interrupt_H_
#define __Interrupt_H_
#include<reg51.h>
#define uint unsigned int
#define uchar unsigned char

void UESC_TNT0Init();	
void UESC_T0Init(uint);	

#endif