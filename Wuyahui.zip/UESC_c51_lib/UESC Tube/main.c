#include<reg51.h>
#include"../8bittube.h"

main()
{
	
	while(1)
	{
		UESC_TubeDisplay_Bit(1,2);
	}
}						  