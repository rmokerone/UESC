#ifndef __DS18B20_H_
#define __DS18B20_H_
#include<reg51.h>
#include<intrins.h>
#define uint unsigned int
#define uchar unsigned char
sbit DQ=P2^2;

void DSreset(void);
void DSwrite(uchar);
uint get_temp();
void tempchange(void);
uint DSread(void);
void DSReadcom();

#endif