#include"../DS18B20.h"
#include"../8bittube.h"
void main()
{
	while(1)
		UESC_TubeDisplay(get_temp());
}
