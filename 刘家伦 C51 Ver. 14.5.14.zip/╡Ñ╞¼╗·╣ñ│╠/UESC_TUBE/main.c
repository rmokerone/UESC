#include "../tube.h"
#include "../stc12.h"

#define BIT_DISPLAY
void main()
{
	#ifndef BIT_DISPLAY
	while(1) TubeDisplay(4532);
	#else	
	while(1) TubeDisplay_bit(1 , 4);
	#endif
}