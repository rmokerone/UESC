#include "../STC12.h"
#include "../1602.h"

uint8 Text1[]="I Love You!";
uint8 Text2[]="My Little Orange";

void main()
{
	uint8 i;
	Lcd_Init();
	Lcd_CR(1,3);
	for (i=0;i<11;i++)
		Lcd_WriteData(Text1[i]);
	Lcd_CR(2,0);
	for (i=0;i<16;i++)
		Lcd_WriteData(Text2[i]);
	while(1);
}
