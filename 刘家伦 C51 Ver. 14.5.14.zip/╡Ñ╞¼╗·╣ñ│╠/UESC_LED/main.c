#include "../stc12.h"
#include "../LED.H"
#include "../KEY.H"

void main()
{
	while(1)
	{
		P1|=~(0x01<<(2));
	}
}
		