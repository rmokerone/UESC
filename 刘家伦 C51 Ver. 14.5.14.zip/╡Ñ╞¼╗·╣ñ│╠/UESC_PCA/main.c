#include "../PCA.h"
#include "../STC12.h"

void main()
{
	uint8 choose;
	choose = 0;
	PCA_Init();
	switch (choose){
	case 0:	PCA_Capture(0, 1);break;
	case 1:	PCA_PWM(1, 20);break;
	case 2: PCA_Soft_Timer(1, 120000);break;
	default:break;}
    while (1);
}