#include "../STC12.H"
#include "../I2C_SOFT.H"

byte I2C_Data;
void main()
{
	I2C_Start();
	I2C_SendByte(0xa0, 1);
	I2C_Data=I2C_ReadByte();
	I2C_Stop();
	while(1);
}