#include "../stc12.h"
#include "../dig.h"

uint16 flag = 0;
uint8 Num[4];

uint8 DigData[4];								//��Ŷ�ѡ4λ��ֵ ע����ͷ�ļ��� extern uint8 DigData[4]; ֻ�����������Ƕ���

uint8 code duan[]={								//����С�����0-9����
					0x05,0x7d,0x46,0x54,0x3c,
					0x94,0x84,0x5d,0x04,0x14};

void InitTimer0(void)
{
    TMOD = 0x01;								//��ֵΪ10ms
    TH0 = 0x0D8;
    TL0 = 0x0F0;
    EA = 1;
    ET0 = 1;
    TR0 = 1;
}

void DigInit()
{
	uint8 i;
	for (i=0;i<4;i++)
	DigData [i] = duan[Num[i]]; 
}

void Process()
{
	if (flag == 9999) flag = 0;
	Num[0] = flag/1000;
	Num[1] = flag%1000/100;
	Num[2] = flag%100/10;
	Num[3] = flag%10;
}
	 
void main()
{
	InitTimer0();
	while(1)
	{
		Process();
		DigInit();
		DigDisplay();
	}
}


void Timer0Interrupt(void) interrupt 1
{
    TH0 = 0x0D8;								//��ֵΪ10ms
    TL0 = 0x0F0;
    flag++;
}
	