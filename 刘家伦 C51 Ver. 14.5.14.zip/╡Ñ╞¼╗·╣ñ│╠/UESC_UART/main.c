#include "../UART.h"
#include "../STC12.H"

unsigned char str[]="I Love UESC!";

void main()
{
	UART_Init(2400);
	UART_PutString(str);
	while(1)
	UART_Getchar();
}