#include "../STC12.H"
#include "../NRF24L01.H"

uint8 seg[10]={0xC0,0xCF,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};

void main(void)
{
	unsigned char tf =0;
	unsigned char TxBuf[20]={0};
	unsigned char RxBuf[20]={0};	
    init_NRF24L01() ;
	led0=0;led1=0;led2=0;led3=0;
	P0=0x00;
	TxBuf[1] = 1 ;
	TxBuf[2] = 1 ;
	nRF24L01_TxPacket(TxBuf);	// Transmit Tx buffer data
	Delay(6000);
	P0=0xBF;
	while(1)
	{
    	if(KEY1 == 0) 
	  	{
			P0=seg[1];
		    TxBuf[1] = 1;
		    tf = 1 ; 
	    }
	   if(KEY2 == 0)
	   {
			P0=seg[2];
			TxBuf[2] = 1;
			tf = 1 ; 
	   }
	   if (tf == 1)
       {	
			nRF24L01_TxPacket(TxBuf);	// Transmit Tx buffer data
			TxBuf[1] = 0x00;
			TxBuf[2] = 0x00;
			tf=0;
			Delay(1000);
	   }
		SetRX_Mode();
		nRF24L01_RxPacket(RxBuf);
   		if(RxBuf[1]|RxBuf[2])
		{					
			if(RxBuf[1]==1)
			{ P0=seg[3];}
			if(RxBuf[2]==1)
			{P0=seg[4]; }
			Delay(1000);
		}
		RxBuf[1] = 0x00;
		RxBuf[2] = 0x00;
}
}
