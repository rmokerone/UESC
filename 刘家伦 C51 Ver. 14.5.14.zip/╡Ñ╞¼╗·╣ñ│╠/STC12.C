#include "STC12.H"

void delayms (uint16 xms)
{
	uint8 i,j;
	uint16 h;	
	for(h=0;h<xms;h--)
	{
		_nop_();
		_nop_();
		i = 20;
		j = 112;
		do
		{
			while (--j);
		} while (--i);
	}
}
