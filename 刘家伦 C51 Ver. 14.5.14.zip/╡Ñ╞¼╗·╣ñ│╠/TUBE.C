#include "TUBE.H"

uint8 TubeData[4];

uint8 code duan[]={							
					0x05,0x7d,0x46,0x54,0x3c,
					0x94,0x84,0x5d,0x04,0x14};

BOOL TubeDisplay(uint16 number)
{	
	uint8 i;
	if (number > 9999 || number < 0) return FALSE;

	TubeData[0] = number/1000;
	TubeData[1] = number%1000/100;
	TubeData[2] = number%100/10;
	TubeData[3] = number%10;

	for(i=0;i<4;i++)
	{
		switch(i)			
		{
			case(0):
				com1 = 0;com2 = 1;com3 = 1;com4 = 1; break;
			case(1):
				com1 = 1;com2 = 0;com3 = 1;com4 = 1; break;
			case(2):
				com1 = 1;com2 = 1;com3 = 0;com4 = 1; break;
			case(3):
				com1 = 1;com2 = 1;com3 = 1;com4 = 0; break;
		}
		P0=duan[TubeData[i]];			
		delayms(20);
		P0=0x00;			
	}
	return TURE;
}

BOOL TubeDisplay_bit(uint8 number , uint8 Tube_bit)
{
	if (number > 10 || number < 0) return FALSE;
	switch (Tube_bit)
	{
		case(1):
		com1 = 0;com2 = 1;com3 = 1;com4 = 1; break;
		case(2):
		com1 = 1;com2 = 0;com3 = 1;com4 = 1; break;
		case(3):
		com1 = 1;com2 = 1;com3 = 0;com4 = 1; break;
		case(4):
		com1 = 1;com2 = 1;com3 = 1;com4 = 0; break;
		default : return FALSE;break;
	}
	P0 = duan[number];
	delayms(20);
	P0 =0x00;
	return TURE;
}