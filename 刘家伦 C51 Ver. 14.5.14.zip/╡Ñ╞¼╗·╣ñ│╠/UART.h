#ifndef __UART_H_
#define __UART_H_

#include "STC12.H"

void UART_Init(uint);
void UART_Getchar();
void UART_Putchar(char);
void UART_PutString(char *);

#endif
