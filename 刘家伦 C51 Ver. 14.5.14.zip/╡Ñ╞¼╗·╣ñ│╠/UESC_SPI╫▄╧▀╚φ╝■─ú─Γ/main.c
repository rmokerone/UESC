#include "../STC12.H"
#include "../SPI_SOFT.H"

#define Buf_Width 4
byte Test_Buf[Buf_Width] = {0x01,0x35,0xFE,0xEA};

sbit CE	  = P1^1;

void main()
{
	CE=0;	//ICʹ��
	CSN=1;
 	SCK=0;
	SPI_Write_Buf(0x20+0x10, Test_Buf, Buf_Width);
	SPI_Read_Buf(0x20+0x10, Test_Buf, Buf_Width);
	SPI_RW_Reg(0x20+0x01, 0x01);
	SPI_Read(0x20+0x01);    
	while(1);
}
