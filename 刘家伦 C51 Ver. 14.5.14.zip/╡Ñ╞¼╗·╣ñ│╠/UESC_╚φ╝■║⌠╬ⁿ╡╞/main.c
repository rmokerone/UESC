#include <reg51.h>

typedef unsigned int uint;
typedef unsigned char uchar;

void delay(uint z)
{
	while(z--);
}

void main()
{
	int i;
	while(1)
	{
		for(i=0;i<1000;i++)
		{
			P1=0x00;
			delay(i);
			P1=0xff;
			delay(1000-i);
		}
		for(i=1000;i>0;i--)
		{
			P1=~0xff;
			delay(i);
			P1=~0x00;
			delay(1000-i);
		}
	}
}