#ifndef __DS18B20_H__
#define __DS18B20_H__

#include "stc12.h"

sbit dsio = P2^2;

void Ds18b20_Init();
void Ds18b20_WriteByte(uint8);
uint8 Ds18b20_ReadByte();
void  Ds18b20_ChangeTemp();
void  Ds18b20_ReadTempCom();
int16 Ds18b20_ReadTemp();

#endif