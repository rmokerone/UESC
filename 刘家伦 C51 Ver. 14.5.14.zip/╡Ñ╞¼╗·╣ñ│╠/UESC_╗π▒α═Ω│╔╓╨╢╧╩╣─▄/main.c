#include "../STC12.H"

#pragma ASM
	ORG 000BH
	LJMP TIMER0
#pragma ENDASM

unsigned int ms_count=1000;

void EX0_Interrupt() interrupt 0 using 0		//ʹ�üĴ����飬����ʵ�ֿ��ٵ�ѹ/��ջ
{ 
	#pragma ASM
	SETB    TR0
	CLR    0x90.2
	CLR    TI
	SETB    ES
	MOV    SBUF,0x20
	MOV    0x20,#0x00
	SETB    0x21.7
	JNB    IT0,$
	CLR    TI
	SETB    ES
	MOV    SBUF,0x20
	MOV    0x20,#0x00
	#pragma ENDASM  
}

void I_Serial() interrupt 4 using 0
{
#pragma ASM
	CLR     TI
	CLR     ES
	MOV     SBUF,0x21
	MOV     0x21,#0x00
#pragma ENDASM  
}

#pragma ASM
TIMER0:      
	MOV    A,0x20
	ADD    A,#0x01
	MOV    0x20,A
	MOV    A,0x21
	ADDC    A,#0x00
	MOV    0x21,A
	JNB    0x21.5,_TIMER0_RET
	CLR    TR0
	SETB    0x90.2
	MOV    0x20,#0x00
	MOV    0x21,#0x00
_TIMER0_RET:   
	RETI
#pragma ENDASM    

void main(void)
{
    SCON=0x40;
    TMOD=0x22;
    TH1=0xff;
    TL1=0xff;
    TH0=0xdb;
    TL0=0xdb;
    PCON=0x80;
#pragma ASM //bdata ������
    MOV 0x20,#0x00
    MOV 0x21,#0x80
#pragma ENDASM  
    EA=1;
    EX0=1;
    IT0=0;
    ET0=1;
    TR1=1;
    PS=1;
    PT0=1;
    IT0=1;
    TR0=1;
    while(1);
}
