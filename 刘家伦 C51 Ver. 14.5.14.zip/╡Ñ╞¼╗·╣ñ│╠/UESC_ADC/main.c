#include "../STC12.H"
#include "../TUBE.H"
#include "../ADC.H"

uint16 result;

void main()
{
	AD_Init();
	result = AD_Get(1);
	TubeDisplay_bit(5,2);
	while(1)
	TubeDisplay(result);
}