/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                          (c) Copyright 1992-2002, Jean J. Labrosse, Weston, FL
*                                           All Rights Reserved
*
*
*                                           uCOS_51 for MCS-51
*
* File : system.h
* By   : Jean J. Labrosse
* Created by : QQ 591881218
*********************************************************************************************************
*/

void InitSystem(void) REENTRANT; // ϵͳ��ʼ��
void LogoDisp(void) REENTRANT; // Logo display
