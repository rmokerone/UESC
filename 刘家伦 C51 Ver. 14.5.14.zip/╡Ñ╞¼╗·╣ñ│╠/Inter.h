#ifndef _INTER_H__
#define _INTER_H__

#include "STC12.H"

void Timer_Init(uint8 module, uint8 mode, uint16 time);
void EX_Init(uint8 module, uint8 mode);

#endif