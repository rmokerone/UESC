#include "LED.H"
#include "stc12.h"

void UESC_OpenLED(uint8 IO)
{
	switch (IO/10)
	{
		case 0:P0|=~(0x01<<(IO%10));break;
		case 1:P1|=~(0x01<<(IO%10));break;
		case 2:P2|=~(0x01<<(IO%10));break;
		case 3:P3|=~(0x01<<(IO%10));break;
		default:break;
	}
}