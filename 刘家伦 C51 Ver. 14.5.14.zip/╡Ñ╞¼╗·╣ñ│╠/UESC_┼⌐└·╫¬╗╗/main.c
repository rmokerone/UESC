#include "../STC12.h"
#include "../Nongli.h"

void main()
{
	while(1);
}