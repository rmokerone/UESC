#include "../key.h"
#include "../stc12.h"

void main(void)
{    
    uint8 KeyValue = KEY_NULL;
    KeyInit() ;
    while(1)
    {
		KeyScan() ;
        GetKey(&KeyValue) ;
        if(KeyValue == (KEY_VALUE_1 | KEY_DOWN)) P1 = ~0x01 ;	   //����,����,����,�ͷ�
        if(KeyValue == (KEY_VALUE_1 | KEY_LONG)) P1 = ~0x02 ;
        if(KeyValue == (KEY_VALUE_1 | KEY_CONTINUE)) P1 = ~0x04 ;
        if(KeyValue == (KEY_VALUE_1 | KEY_UP)) P1 = ~0x08 ;
    }

}
