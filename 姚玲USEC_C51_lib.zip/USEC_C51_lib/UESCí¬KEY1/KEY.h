#include <reg51.h>
void TestKey();
void delayms(unsigned int xms);
void OpenLed(unsigned int io);
void CloseLed(unsigned int io);
sbit key1=P3^1;
sbit key2=P3^2;
sbit key3=P3^3;
sbit key4=P3^4;
#define P10 10
#define P11 11
#define P12 12
#define P13 13
#define P14 14
#define P15 15
#define P16 16
#define P17 17

