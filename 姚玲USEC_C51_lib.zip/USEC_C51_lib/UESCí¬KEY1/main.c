#include<reg51.h>
#include<KEY.h>
void main()
{
while(1)
{
TestKey();
}
}