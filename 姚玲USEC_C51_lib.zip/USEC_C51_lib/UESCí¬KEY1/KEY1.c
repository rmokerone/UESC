#include<reg51.h>
#include<KEY.h>

void TestKey()
{
if(key1==0)
delayms(10);
{
	if(key1==0)
	{
	OpenLed(17);

	while(!key1);
	
	 }
	}
if(key2==0)
delayms(10);
{
	if(key2==0)
	{

	CloseLed(17);
	while(!key2);
	
	}
	}
if(key3==0)
{
	delayms(10);
	if(key3==0);
	{

	OpenLed(15);
	while(!key3);
	
	 }
	}
if(key4==0)
{
	delayms(10);
	if(key4==0)
	{
	CloseLed(15);
	while(!key4);
	
	}
	}
}
void delayms(unsigned int xms)
{
unsigned int  i,j;
for(i=xms;i>0;i--)
for(j=110;j>0;j--);
}
void OpenLed(unsigned int io)
{
   switch(io/10)
   {
   case 1:P1&=~(1<<io%10);
   break;
   }
}
void CloseLed(unsigned int io)

{
	switch(io/10)
	{
	case 1:
		P1 |= (1<<io%10);
	}
}