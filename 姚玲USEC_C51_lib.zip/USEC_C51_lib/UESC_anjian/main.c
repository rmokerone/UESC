#include<reg51.h>
#include"..\key.h"
#include"..\8bittube.h"
void main()
{	 
	
	 
	unsigned long int number=0;
	unsigned long int tabbit=0;
	UESC_TubeDisplay_Bit(number, tabbit) ;
	while(1)
	{
	if(UESC_Key(31))
	 { 
	 number=number+1;	
	 while(UESC_Key(31));
	 }
   	UESC_TubeDisplay_Bit(number, tabbit) ;
	}
}	 
  	
 

	
	

