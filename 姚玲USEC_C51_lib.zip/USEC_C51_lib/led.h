 #include<reg51.h>
 void UESC_OpenLed(unsigned char io);
 void UESC_CloseLed(unsigned char io);
 void delay(unsigned int xms);

  
 
 #define P10 10
 #define P11 11
 #define P12 12
 #define P13 13
 #define P14 14
 #define P15 15
 #define P16 16
 #define P17 17
 #define P00 0
 #define PO1 1
 #define P02 2
 #define P03 3 
 #define P04 4
 #define P05 5
 #define P06 6
 #define P07 7