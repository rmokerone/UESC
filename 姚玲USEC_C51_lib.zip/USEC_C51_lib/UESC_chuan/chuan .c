 #include<reg51.h>
 #include<intrins.h>
 #include"chuan.h"
 #define PARITYBIT NONE_PARITY 
 void UESC_Init() 
{
 

  	SCON = 0x50;  
  	TMOD=0x20;
   	TL1 = (65536 - (FOSC/4/BAUD));   //���ò�������װֵ
   	TH1 = (65536 - (FOSC/4/BAUD))>>8;
   	TR1 = 1;                    //��ʱ��1��ʼ����
   	ES = 1;                     //ʹ�ܴ����ж�
   	EA = 1;
}
void main()
{	
	UESC_Init() ;
	while(1)
	{
		if(flag==1)
		{
				ES=0;
				a=0xfe;
				while(1)
			{
				P1=a;
				delayms(50);
				a=_crol_(a,1);
			} 
		
			
		
				SBUF=a;
				while(!TI);
				TI=0;
				ES=1;
				flag=0;
		}
	}
}
void ser() interrupt 4
{
	RI=0;
	a=SBUF;
	flag=1;
}
void delayms(unsigned int xms)
{
	unsigned int  i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);
}	