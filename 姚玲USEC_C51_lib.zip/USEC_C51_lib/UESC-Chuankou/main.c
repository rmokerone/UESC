#include<reg51.h>
#include<intrins.h>
#include"..\UART.h"
void main()
{
	UESC_JART_Init(115200);

	   UESC_UART_Getchar() ;
		
	}