 #include <reg51.h>
 #include"../Nixietube.h"

 void main()
 {


 	while (1)
	{
		if(UESC_key(31))
   		Nixietubedisplay(10,19);
		
	} 
}