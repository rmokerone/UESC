 #include <reg51.h>
 #include"led.h"

 void UESC_OpenLed(unsigned char io)
{
	switch (io/10)
	{
	case 0:

		P0&=~(1<<io%10);
		break;

	case 1:

		P1&= ~(1<<io%10);

		break;
		}
}
void UESC_CloseLed(unsigned char io)
{	
	switch(io/10)
	{
	case 0:P0|=(1<<io%10);
	break;
	case 1:P1|=(1<<io%10);
	break;
	}

}
void delay(unsigned int xms)
{
unsigned int i,j;
for(i=xms;i>0;i--)
	for(j=110;j>0;j--);
}


