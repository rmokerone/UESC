#include<reg51.h>
#define uint unsigned int
sbit key1=P3^2;
void UESC_Get();
void delayms(uint xms);