#include<reg51.h>
#include<intrins.h>
#include"interrupt.h"
void UESC_Get()
{
unsigned int aa;
if(key1==0)
{
	aa=0xfe;
	P1=aa;
		}
	
	
}	

