#include<reg52.h>
#include<PCA.h> 
sbit led1=P1^0;
sbit led7=P1^7;
uchar aa;
void main() 
{
	 CCON = 0;                       //Initial PCA control register
                                 
                                    //Clear all module interrupt flag
	CL = 0;                         //Reset PCA base timer
    CH = 0;
    CMOD = 0x00;                    //Set PCA timer clock source as Fosc/12
	UESC_PCA_CAPTURE(0,0x11);
	CR = 1;                         //PCA timer start run
    EA = 1;

    while (1) ;
}
void   PCA_() interrupt 7 using 1
	{
		CCF0=0;
	   	led1=!led1;
		led7=!led7;
		while(1)
		{
		 Nixie_TubeDisplay(1000);
		 }	

	
	}