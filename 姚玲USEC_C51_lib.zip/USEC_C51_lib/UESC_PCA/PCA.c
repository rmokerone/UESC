#include<reg52.h>
#include<PCA.h>
unsigned char code Disp_Tab[] = {0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
unsigned char wei[]={0xd0,0xe0,0x70,0xb0};

void UESC_PCA_CAPTURE(char module ,mode)
{
	switch(module)
	{
	case 0: CCAPM0=mode;
	break;
	case 1: CCAPM1=mode;
	break;
	
	}
}
void Nixie_DelayXms(unsigned int xms)
 {
       unsigned char i;

	   for(; xms>0; xms--)
	   {
	        for(i=110; i>0; i--);
	   }
 }

/*
 *	�������ʾ����
 *
 **/
 void Nixie_TubeDisplay(unsigned int num)
 {
 	 unsigned char i = 0;
	 unsigned char LedOut[4];

      LedOut[3] = Disp_Tab[num%10000/1000];
      LedOut[2] = Disp_Tab[num%1000/100]&0xfb;  //  &0xfb��ʾС���㡣ȥ������ʾ
      LedOut[1] = Disp_Tab[num%100/10];	 //ʮλ
      LedOut[0] = Disp_Tab[num%10];  
	    
	 for(i=0; i<4; i++)
	 { 
		 P2 = wei[i];
	     P0 = LedOut[i];
	     
		 Nixie_DelayXms(2); 
	 }	
 }
