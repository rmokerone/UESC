#include<reg51.h>

#include"Nixietube.h"

 unsigned char tab[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
 unsigned char wei[]={0xd0,0xe0,0x70,0xb0};
  	
void delayms(unsigned int xms)
	{	unsigned int i,j;
  	for(i=xms;i>0;i--)
  	{	
	for(j=110;j>0;j--);
	}
}
 void  Nixietubedisplay(unsigned char num1,unsigned char num2)
{
unsigned char i=0;
unsigned char LedOut[4]; 
		  LedOut[3] = tab[num1/10];
	      LedOut[2] = tab[num1%10]&0xfb;  //  &0xfb��ʾС���㡣ȥ������ʾ
	      LedOut[1] = tab[num2/10];	 //ʮλ
	      LedOut[0] = tab[num2%10];
for(i=0;i<4;i++)
{
P2=wei[i];
P0=LedOut[i];
delayms(5);
}
}
char UESC_key(unsigned char io)
{
char b=0;
switch(io/10)
{
case 3:	if(!(P3&(1<<(io%10))))
		b=1;
		break;

}

return (b);
}	