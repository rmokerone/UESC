#include<reg52.h>
#define uchar unsigned char
#define uint unsigned int
sbit ds=P2^2;  

void dsreset(void);
bit tempreadbit(void);
uchar tempread(void);
void tempwritebyte(uchar dat);
uint get_temp();
void display(uint num);