#include<reg52.h>
#include<DS18b20.h>
#include<intrins.h>
void main()
{


while(1)
{
display(get_temp());

} 

}