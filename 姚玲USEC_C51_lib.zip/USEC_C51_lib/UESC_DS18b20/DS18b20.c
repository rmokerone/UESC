#include<reg52.h>
#include<intrins.h>
#include<DS18b20.h>

unsigned char code tab[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
unsigned char wei[]={0xd0,0xe0,0x70,0xb0};

 /*��λ*/
void dsrest(void)
{
	
	uchar i,j;
	ds=1;  /*�øߵ�ƽ*/
	i = 3; //��ʱ2us ��ʱ�����ܵĶ�
	while (--i);
	
	ds=0; //����������
	_nop_();
	_nop_();
	i = 9;	//��һ��480~960�ĵ͵�ƽ��λ�źţ�ʹ�������ϵ���������������λ
	j = 189;
	do
	{
		while (--j);
	} 	while (--i);
	
	ds=1;
	_nop_();
	_nop_();  //��ʱ60us
	i = 1;
	j = 175;
	do
	{
		while (--j);
	} while (--i);

	_nop_();
	_nop_();
	i = 6;
	j = 150;
	do
	{
		while (--j);
	} while (--i);
	ds=1;

}

	
bit tempreadbit(void)
{
	bit dat;
	uchar i;
	ds=1;
	i = 3;			  //��ʱ2us
	while (--i);
	
	ds=0;
	i = 15;		//��ʱ6us
	while (--i);

	ds=1;
	_nop_();
	_nop_();
	i = 9;
	while (--i);//��ʱ4us
	dat=ds;
  	
	 _nop_();
	_nop_();
	i = 87;		 //��ʱ30us
	while (--i);
	return(dat);
}
uchar tempread(void)
{
	uchar value, d,j;
	value=0;
	for(d=1;d<=8;d++)
	{
	j=tempreadbit();
	value=(j<<7)|(value>>1);
	}
	return(value);
}
void tempwritebyte(uchar dat)
{
  	uchar i,j;
	bit testb;
	
	for(j=1;j<=8;j++)
		{
			testb=dat&0x01;
			dat>>=1;
			if(testb)
				{
				ds=0;
				i = 42;	while (--i);//����15us
				ds=1;

				_nop_();
				_nop_();
				i = 1; 
				j = 130;//yanshi45
				do
				{
				while (--j);
				} while (--i);
				ds=1;
				}
			
		
		else 
		{
		ds=0;
	   	i = 42;	while (--i);//����15us
		ds=0;
		_nop_();
		_nop_();
		i = 1;
		j = 130;
		do
		{
		while (--j);
		} while (--i);	
		
		ds=1;
		}
		 }
}


	uint get_temp()
 {
	uchar a,b;
	uint temp;
	float f_temp;
	dsrest();
   	tempwritebyte(0xcc);
	tempwritebyte(0x44);
	dsrest();
	tempwritebyte(0xcc);
	tempwritebyte(0xbe);
	a=tempread();
	b=tempread();
	temp=b;
	temp<<=8;
	temp=temp|a;
	f_temp=temp*0.0625;
	temp=f_temp*100+0.5;
	return (temp);
}




void  display(uint num)
{
unsigned char i=0,j;
unsigned char LedOut[4]; 
			LedOut[3] = tab[num%10000/1000];
	      LedOut[2] = tab[num%1000/100];  //  &0xfb��ʾС���㡣ȥ������ʾ
	      LedOut[1] = tab[num%100/10];	 //ʮλ
	      LedOut[0] = tab[num%10];
for(i=0;i<4;i++)
{
P2=wei[i];
P0=LedOut[i];
	_nop_();
	_nop_();
	_nop_();
	j= 5;
	while (--j);
}
}



