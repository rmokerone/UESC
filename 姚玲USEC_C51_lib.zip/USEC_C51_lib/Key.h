#include <reg51.h>
char UESC_Key(unsigned char io);

#define P31 31
#define P32 32
#define P33 33
#define P34 34
#define P35 35
#define P36 36
#define P37 37