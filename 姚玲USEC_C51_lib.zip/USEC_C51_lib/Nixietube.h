#ifndef __NIXIETUBE_H__
#define __NIXIETUBE_H__
#include<reg51.h>


 void  Nixietubedisplay(unsigned char num1,unsigned char num2);
 void delayms(unsigned int xms);
 char UESC_key(unsigned char io);

 #endif
 