#include<reg51.h>
#include"..\8bittube.h"
void main()
{ 

 UESC_TubeDisplay_Bit(1234,0);
}