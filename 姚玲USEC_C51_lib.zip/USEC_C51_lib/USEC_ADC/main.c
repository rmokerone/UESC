#include <reg51.h>
#include"intrins.h"
#include"ADC.h"

void main()
{
  uint gall;
 UESC_AD_InitADC();

 while(1)
 {
 UESC_AD_GetVol(gall);
 }
 }