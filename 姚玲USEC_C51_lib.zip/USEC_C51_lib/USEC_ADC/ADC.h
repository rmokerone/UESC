 
 
 
 #include <reg51.h>
#include"intrins.h"
#define uchar unsigned char
#define uint unsigned int
#define FOSC    18432000L
#define BAUD    9600

 unsigned char code Disp_Tab[] = {0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
 unsigned char wei[]={0xd0,0xe0,0x70,0xb0};


/*Declare SFR associated with the ADC*/
	sfr ADC_CONTR=0xBC;
	sfr ADC_RES=0xBD;           //ADC high 8-bit result register
	sfr ADC_LOW2=0xBE;  
	sfr P1ASF=0X9D;

#define ADC_POWER 0x80
#define ADC_FLAG  0x10	/*ģ��ת������λ*/
#define ADC_START 0x08	 /*ģ��ת����������λ*/

#define ADC_SPEEDLL 0x00//540clocks
#define ADC_SPEEDL 0x20	//360clocks
#define ADC_SPEEDH 0x40 //180clocks
#define ADC_SPEEDHH 0x60 //90clocks
void delay (uint n);
void UESC_AD_InitADC();
uint UESC_AD_Send(uint  gall);

void UESC_AD_GetVol(uint  gall);
void Nixie_DelayXms(unsigned int xms) ;
 void Nixie_TubeDisplay(unsigned int num);