#include<reg51.h>
#include"8bittube.h" 
unsigned char code Tube_line[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
unsigned char code Tube_row[]={0xd0,0xe0,0x70,0xb0};
void delayms(unsigned int xms)
{
unsigned char j;
	for(;xms>0;xms--)
	{
		for(j=110;j>0;j--);
	}
}
void UESC_TubeDisplay_Bit(unsigned char number,unsigned char  tabbit)

{
  			
		 unsigned char singlenum[4];
	   if(number < 10)
	   	{
	       P0=Tube_line[number];
		  
		   P2 =Tube_row[tabbit];
		  	delayms(1);
			
		}
	

	
	else
		{	 
   			 P2 = 0xff;
			
		   singlenum[tabbit] = Tube_line[number%10];
		  // number=number/10;
		   P0 = singlenum[tabbit];
		   P2 = Tube_row[tabbit];
		   delayms(1);
		  
		  UESC_TubeDisplay_Bit(number/10, tabbit+1);	 //���ñ��� 
	 		
		}
}
