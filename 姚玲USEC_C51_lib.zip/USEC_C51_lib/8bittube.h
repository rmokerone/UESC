
#include<reg51.h>


void UESC_TubeDisplay_Bit(unsigned char number,unsigned char  tabbit);
void delayms(unsigned int xms);




