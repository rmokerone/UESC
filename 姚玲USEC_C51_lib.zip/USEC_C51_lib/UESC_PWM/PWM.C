#include<reg51.h>
#include<PWM.H>
void UESC_PCA_Init()
{
CCON=0;
CL=0;
CH=0;
CMOD=0x08;
CR = 1;
}
void UESC_PCA_PWM(uchar moddle ,width)
{
UESC_PCA_Init();
switch(moddle)
{
case 0: CCAPM0 = 0x42;
		CCAP0H = CCAP0L =width;
break;
case 1: CCAPM1 = 0x42;
		CCAP1H = CCAP1L =width;
break; 
}
}