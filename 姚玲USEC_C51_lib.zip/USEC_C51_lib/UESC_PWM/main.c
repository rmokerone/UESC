#include<reg51.h>
#include<PWM.H>
void main()
{
UESC_PCA_PWM(0,20);
UESC_PCA_PWM(1,20);
}