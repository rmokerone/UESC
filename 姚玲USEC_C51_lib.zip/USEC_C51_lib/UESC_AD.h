#ifndef _UESC_AD_H_
#define _UESC_AD_H_

#include <reg51.h>
#include"intrins.h"
#define uchar unsigned char
#define uint unsigned int
#define FOSC    18432000L
#define BAUD    9600




/*Declare SFR associated with the ADC*/
	sfr ADC_CONTR=0xBC;
	sfr ADC_RES=0xBD;           //ADC high 8-bit result register
	sfr ADC_LOW2=0xBE;  
	sfr P1ASF=0x9D;
	sfr AUXR1=0xA2;

#define ADC_POWER 0x80
#define ADC_FLAG  0x10	/*ģ��ת������λ*/
#define ADC_START 0x08	 /*ģ��ת����������λ*/

#define ADC_SPEEDLL 0x00//540clocks
#define ADC_SPEEDL 0x20	//360clocks
#define ADC_SPEEDH 0x40 //180clocks
#define ADC_SPEEDHH 0x60 //90clocks
void delay (uint n);
void  UESC_AD_InitADC(gall);
uint  UESC_AD_Getdata(gall);
void Nixie_DelayXms(uint xms) ;
void Nixie_TubeDisplay(uint num);
float UESC_AD_VOLL(voll,gall);
void UESC_AD_UART();
 #endif