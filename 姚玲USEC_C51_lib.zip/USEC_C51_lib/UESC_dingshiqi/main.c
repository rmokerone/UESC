#include<reg51.h>
#include"dingshiqi.h"
sbit led1=P1^3;
uchar num1,num2;
void main()
{ 
	led1=0;
	Init();
		while(1)
	{
 	display(num1,num2);
 	}
}
void Timer0() interrupt 1
{
	unsigned int number;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	number++;
	if(number==20)
	{
	led1=~led1;
	number=0;
	num2++;
	}
	if(num2==60)
	{
	num1++;
	num2=0;
	}
}