#include<reg51.h>
#define uint unsigned int
#define uchar unsigned char
void display(uchar num1,num2);
void delayxms(unsigned int xms);
void Init();