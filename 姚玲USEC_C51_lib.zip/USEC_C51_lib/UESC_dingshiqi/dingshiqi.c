#include<reg51.h>
#include"dingshiqi.h"
unsigned char code tab[]={0x05,0x7d,0x46,0x54,0x3c,0x94,0x84,0x5d,0x04,0x14};
unsigned char code wei[]={0xd0,0xe0,0x70,0xb0};
void Init()
{
	TMOD=0x01;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	EA=1;
	ET0=1;
	TR0=1;

}
 void delayxms(uint xms)
{	
	unsigned int i,j;  

  	for(i=xms;i>0;i--)
  	{	
	for(j=110;j>0;j--);
	}
}
void display(uchar num1,num2)
{
	unsigned char i=0;
	unsigned char LedOut[4]; 
		LedOut[3] = tab[num1/10];
	    LedOut[2] = tab[num1%10]&0xfb;  //  &0xfb��ʾС���㡣ȥ������ʾ
	    LedOut[1] = tab[num2/10];	 //ʮλ
	    LedOut[0] = tab[num2%10];
	for(i=0;i<4;i++)
	{
	P2=wei[i];
	P0=LedOut[i];
	delayxms(5);
	}
}	
