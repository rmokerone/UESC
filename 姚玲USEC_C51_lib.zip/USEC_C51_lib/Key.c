#include <reg51.h>
#include "Key.h"
 char UESC_Key(unsigned char io)
 {
	 
char b=0;
switch(io/10)
{
case 3:	if(!(P3&(1<<(io%10))))
		
		b=1;
		break;

}

return (b);


}
