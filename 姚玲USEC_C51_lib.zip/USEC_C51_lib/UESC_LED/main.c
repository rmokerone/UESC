#include <reg51.h>
#include "../led.h"
	
void main()
{
	UESC_OpenLed(15);
	delay(500);
	UESC_CloseLed(15);
	delay(500);	
	
}