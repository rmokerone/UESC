 #include"../led.h"
 void UESC_LED(unsigned char io)
{
	switch (io/10)
	{
	case 0:

		P0&=~(1<<io%10);
		break;

	case 1:

		P1&= ~(1<<io%10);

		break;
		}
}