#include <reg51.h>
#include"intrins.h"
#include"..\UESC_AD.H"
  
void main()
{
  
 UESC_AD_InitADC(0)	;
   
	 	 while(1)
		{	Nixie_TubeDisplay(UESC_AD_VOLL(UESC_AD_Getdata(0),0));	
		}
}		
 
 
